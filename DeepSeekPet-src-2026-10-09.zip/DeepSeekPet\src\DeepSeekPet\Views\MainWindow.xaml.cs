using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using DeepSeekPet.Animation;
using DeepSeekPet.Diagnostics;
using DeepSeekPet.Interop;
using DeepSeekPet.Services;
using DeepSeekPet.ViewModels;
using DrawingRectangle = System.Drawing.Rectangle;

namespace DeepSeekPet.Views;

internal partial class MainWindow : Window
{
    /// <summary><see cref="Visual.PointToScreen"/> 给出的位移小于这个值才算点击。</summary>
    private const double ClickMaxMovePx = 4;

    private const long ClickMaxMs = 400;

    /// <summary>鼠标要停留这么久才触发害羞。</summary>
    private const int HoverDwellMs = 500;

    /// <summary>两次害羞之间的最短间隔 —— 桌宠在右下角，鼠标来往太频繁。</summary>
    private const long ShyCooldownMs = 8000;

    private readonly PetViewModel _vm;
    private readonly AppSettings _settings;
    private readonly SettingsStore _settingsStore;
    private readonly SpriteAnimator _animator;

    private IntPtr _hwnd = IntPtr.Zero;
    private readonly DispatcherTimer _saveDebounce;
    private readonly DispatcherTimer _hoverTimer;
    private bool _suppressSave;

    private bool _hovering;
    private long _lastShyAt;

    public event EventHandler? PetClicked;

    public MainWindow(PetViewModel vm, AppSettings settings, SettingsStore settingsStore, SpriteSet sprites)
    {
        InitializeComponent();

        _vm = vm;
        _settings = settings;
        _settingsStore = settingsStore;

        DataContext = vm;
        _animator = new SpriteAnimator(sprites, BaseLayer, FadeLayer, BobTransform);
        _animator.ApplySettings(settings.Animation);   // 总开关为 false 时 Start() 不会启动计时器

        // 先完全透明：窗口在 (0,0) 被创建、到 OnContentRendered 才有真实尺寸可供
        // 定位，若不遮挡，用户会看到它在屏幕左上角闪一下再跳到右下角。
        Opacity = 0;

        _saveDebounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
        _saveDebounce.Tick += (_, _) =>
        {
            _saveDebounce.Stop();
            SavePositionNow();
        };

        // 一次性计时器：进入时启动，响过就停，靠重新进入来重排。
        _hoverTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(HoverDwellMs) };
        _hoverTimer.Tick += OnHoverDwell;

        _lastShyAt = Environment.TickCount64 - ShyCooldownMs;   // 首次悬停不必等冷却
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);

        // HWND 此刻才存在，且窗口尚未激活 —— 这是注入扩展样式的最佳时机
        _hwnd = MonitorHelper.HandleOf(this);
        NativeMethods.HideFromAltTab(_hwnd);
        Log.Info($"主窗口已创建, HWND=0x{_hwnd.ToInt64():X}");
    }

    protected override void OnContentRendered(EventArgs e)
    {
        base.OnContentRendered(e);

        // 等布局完成，窗口才有正确的物理尺寸可用来校验位置
        RestorePosition();
        _animator.Start();
        UpdateStatusDot();   // 就位后把初始的灰点画出来

        Opacity = 1;   // 位置已定，露面
    }

    protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
    {
        base.OnDpiChanged(oldDpi, newDpi);
        // 换到不同缩放比的显示器上，重新吸附一次
        Dispatcher.BeginInvoke(new Action(() =>
        {
            MonitorHelper.SnapToNearestEdge(_hwnd);
            SavePositionDebounced();
        }), DispatcherPriority.Background);
    }

    /// <summary>
    /// 点击与拖拽的消歧。
    ///
    /// <b>语义变更：</b> <see cref="PetClicked"/> 从「任意按下」改为「按下后没怎么移动的松开」。
    /// 原实现在 <c>DragMove()</c> 之前无条件触发，等于<b>每次拖动都顺带刷新一次余额</b>。
    ///
    /// <b>必须比较绝对屏幕坐标，不能比较相对坐标。</b> <c>DragMove()</c> 的语义是让窗口
    /// 始终维持「光标在窗口内的相对位置不变」—— 也就是说光标在窗口坐标系里的位置
    /// 拖完几乎和开始时一模一样，拿它做判据的话<b>每一次拖拽都会被误判成点击</b>。
    /// 而 <see cref="Visual.PointToScreen"/> 给出的是光标在屏幕上的绝对位置，
    /// 拖拽时它确实随光标移动，所以是可用的判据。
    ///
    /// 阈值取 4、时限取 400ms。两端都走同一个方法、同一个坐标空间，所以比较本身
    /// 与单位无关；4 这个数无论被解释成设备像素还是 DIP，都是「几乎没动」的量级。
    /// </summary>
    private void OnPetMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        // 必须看 LeftButton 的当前状态，而不是 e.ChangedButton ——
        // 事件被延迟派发时（比如开了对话框再回来）按钮可能已经松开，
        // 那时 DragMove() 会抛 InvalidOperationException("Can only call DragMove when primary mouse button is down.")。
        if (e.LeftButton != MouseButtonState.Pressed) return;

        var startedAt = Environment.TickCount64;
        var pressedAt = PointToScreen(e.GetPosition(this));

        _animator.BeginPress();
        try
        {
            e.Handled = true;
            DragMove(); // 阻塞直到鼠标松开
        }
        catch (InvalidOperationException ex)
        {
            // 按钮已经被释放，无从判断有没有移动过。当作点击处理 ——
            // 宁可多刷一次余额，也不要让快速点击悄无声息地什么都不做。
            _animator.EndPress();
            Log.Warn($"DragMove 被拒绝（按钮已释放）: {ex.Message}");
            TriggerClick();
            return;
        }

        var moved = (PointToScreen(Mouse.GetPosition(this)) - pressedAt).Length;
        var elapsed = Environment.TickCount64 - startedAt;
        _animator.EndPress();

        // DragMove 返回后才吸附：拖动过程中 LocationChanged 会持续触发，
        // 那时吸附会跟光标打架。
        MonitorHelper.SnapToNearestEdge(_hwnd);
        SavePositionDebounced();

        if (moved < ClickMaxMovePx && elapsed < ClickMaxMs) TriggerClick();
    }

    private void TriggerClick()
    {
        PetClicked?.Invoke(this, EventArgs.Empty);
        _animator.React(PetReaction.Hop);
    }

    /// <summary>
    /// 悬停反应带<b>停留时长 + 限频</b>两道闸。
    ///
    /// 桌宠停在屏幕右下角，那是鼠标来往最频繁的地方 —— 鼠标只是路过就冒爱心的话，
    /// 一天下来能闪几百次，从「活泼」直接变成「吵闹」。所以要求停留 0.5 秒，
    /// 且两次之间至少间隔 8 秒。<see cref="SpriteAnimator.NotifyActivity"/> 无条件调用，
    /// 这样即使反应被限频吞掉了，「有人在碰我」这件事仍然算数，宠物不会在这时睡着。
    /// </summary>
    private void OnPetMouseEnter(object sender, MouseEventArgs e)
    {
        _hovering = true;
        _animator.NotifyActivity();
        _hoverTimer.Stop();
        _hoverTimer.Start();
    }

    private void OnPetMouseLeave(object sender, MouseEventArgs e)
    {
        _hovering = false;
        _hoverTimer.Stop();
        _animator.NotifyActivity();
    }

    private void OnHoverDwell(object? sender, EventArgs e)
    {
        _hoverTimer.Stop();
        if (!_hovering) return;

        var now = Environment.TickCount64;
        if (now - _lastShyAt < ShyCooldownMs) return;

        _lastShyAt = now;
        _animator.React(PetReaction.Shy);
    }

    protected override void OnLocationChanged(EventArgs e)
    {
        base.OnLocationChanged(e);
        SavePositionDebounced();
    }

    private void SavePositionDebounced()
    {
        if (_suppressSave) return;
        _saveDebounce.Stop();
        _saveDebounce.Start();
    }

    /// <summary>把当前位置（物理像素）写进 settings.json。</summary>
    public void SavePositionNow()
    {
        try
        {
            var r = NativeMethods.GetRect(_hwnd);
            if (r.Width <= 0 || r.Height <= 0) return;

            _settings.Window.Left = r.Left;
            _settings.Window.Top = r.Top;
            _settings.Window.MonitorDeviceName = MonitorHelper.CurrentMonitorName(_hwnd);
            _settingsStore.Save(_settings);
        }
        catch (Exception ex) { Log.Error("保存窗口位置失败", ex); }
    }

    /// <summary>
    /// 还原位置，并<b>校验它是否还在某块已连接的显示器上</b>。
    /// 不校验的话，用户拔掉副屏后桌宠会落在屏幕外，表现为“宠物消失了”。
    /// </summary>
    private void RestorePosition()
    {
        try
        {
            var r = NativeMethods.GetRect(_hwnd);
            if (r.Width <= 0 || r.Height <= 0) return;

            var s = _settings.Window;

            if (s.Left is { } sl && s.Top is { } st)
            {
                NativeMethods.MoveWindowPixels(_hwnd, sl, st);

                var after = NativeMethods.GetRect(_hwnd);
                var rect = DrawingRectangle.FromLTRB(after.Left, after.Top, after.Right, after.Bottom);

                if (MonitorHelper.IsOnAnyScreen(rect))
                {
                    Log.Info($"位置已还原: ({after.Left},{after.Top}) @ {s.MonitorDeviceName}");
                    return;
                }

                Log.Warn($"保存的位置 ({sl},{st}) 不在任何已连接显示器上，回落到默认位置");
            }

            var (dx, dy) = MonitorHelper.DefaultPositionPx(r.Width, r.Height);

            // 回落时别再触发一次保存，否则会把“回落结果”当成用户意图写回去
            _suppressSave = true;
            NativeMethods.MoveWindowPixels(_hwnd, dx, dy);
            _suppressSave = false;

            Log.Info($"使用默认位置: ({dx},{dy})");
        }
        catch (Exception ex) { Log.Error("还原窗口位置失败", ex); }
    }

    public void ApplyBalance(Models.BalanceSnapshot snap, bool isLow)
    {
        _vm.Apply(snap, isLow);
        UpdateStatusDot();
    }

    private void UpdateStatusDot()
    {
        StatusDot.Fill = _vm.IsLoading
            ? Rgb(0x6B, 0x72, 0x80)   // 灰：还没拿到数据（别用红色，那会误导成「出错了」）
            : _vm.IsError
                ? Rgb(0xF4, 0x43, 0x36)   // 红：出错
                : _vm.IsLow
                    ? Rgb(0xFF, 0x98, 0x00) // 橙：低余额
                    : Rgb(0x4C, 0xAF, 0x50); // 绿：正常

        BalanceLabel.ToolTip = _vm.StatusText;
    }

    private static SolidColorBrush Rgb(byte r, byte g, byte b) => new(Color.FromRgb(r, g, b));

    public SpriteAnimator Animator => _animator;

    public void PauseAnimation()
    {
        _animator.Pause();
        // 暂停期间不该再冒反应 —— 设置窗弹着的时候背后闪一下很分心
        _hoverTimer.Stop();
        _hovering = false;
    }

    public void ResumeAnimation() => _animator.Resume();

    /// <summary>热应用动效设置（设置窗保存后由 App 调用）。</summary>
    public void ApplyAnimationSettings() => _animator.ApplySettings(_settings.Animation);

    /// <summary>
    /// 用共享清单构建原生 WPF 右键菜单。
    ///
    /// 刻意<b>不复用</b>托盘的 WinForms <c>ContextMenuStrip</c>：本程序从不调用
    /// WinForms 的 <c>Application.Run</c>，没有 WinForms 消息循环，而
    /// <c>ContextMenuStrip.Show()</c> 会另起一个消息泵 —— 在 <c>DragMove()</c> 刚返回、
    /// 或设置窗 <c>ShowDialog()</c> 的模态循环之上再叠一个，是焦点丢失与「点外面不关闭」
    /// 的经典来源。而本窗口是 Topmost + WS_EX_TOOLWINDOW + 分层窗口，激活语义本就特殊。
    /// 声明式 ContextMenu 走框架标准路径，右键弹出 / 外部点击关闭 / Esc / 焦点归还全部免费，
    /// 也不必把 WinForms 引进这个刻意与它隔离的文件。
    /// </summary>
    public void SetPetMenu(IReadOnlyList<PetMenuEntry> entries)
    {
        var menu = new ContextMenu();

        foreach (var entry in entries)
        {
            if (entry.IsSeparator)
            {
                menu.Items.Add(new Separator());
                continue;
            }

            var item = new MenuItem { Header = entry.Text };
            var action = entry.Invoke;
            var label = entry.Text;
            item.Click += (_, _) =>
            {
                try { action(); }
                catch (Exception ex) { Log.Error($"右键菜单「{label}」执行失败", ex); }
            };
            menu.Items.Add(item);
        }

        PetArea.ContextMenu = menu;
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        // 只有 App 真的在退出时才允许关窗。任务管理器的「结束任务」和
        // taskkill（不带 /f）都会发 WM_CLOSE，而本程序是
        // ShutdownMode=OnExplicitShutdown，进程不会因此退出 —— 结果托盘图标
        // 还在，宠物却永远显示不出来了（已关闭的 Window 不能再 Show）。
        if (!App.IsShuttingDown)
        {
            e.Cancel = true;
            Hide();
            PauseAnimation();
            Log.Info("收到关闭请求，改为隐藏（进程继续驻留托盘）");
            return;
        }

        _saveDebounce.Stop();
        SavePositionNow();
        _animator.Dispose();
        base.OnClosing(e);
    }
}
