using System.Threading;
using DeepSeekPet.Diagnostics;

namespace DeepSeekPet.Services;

/// <summary>
/// 单实例锁。两个容易踩的坑都在这里处理了：
///  1. <b>Mutex 必须挂在静态字段上</b> —— 若是局部变量，被 GC 回收时终结器会释放锁，
///     第二个实例就能起来了。
///  2. 用 "Local\" 前缀 —— 只约束当前登录会话，允许两个不同 Windows 用户各跑一只宠物。
/// </summary>
internal sealed class SingleInstance : IDisposable
{
    private const string MutexName = @"Local\DeepSeekPet.SingleInstance.v1";
    private const string ShowEventName = @"Local\DeepSeekPet.ShowEvent.v1";
    private const string ExitEventName = @"Local\DeepSeekPet.ExitEvent.v1";

    // 静态：见类注释第 1 条
    private static Mutex? s_mutex;
    private static EventWaitHandle? s_showEvent;
    private static EventWaitHandle? s_exitEvent;

    public bool IsFirst { get; }

    public SingleInstance()
    {
        s_mutex = new Mutex(initiallyOwned: true, MutexName, out var createdNew);
        IsFirst = createdNew;

        try { s_showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName); }
        catch (Exception ex) { Log.Warn($"创建显示事件失败（不影响单实例）：{ex.Message}"); }

        try { s_exitEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ExitEventName); }
        catch (Exception ex) { Log.Warn($"创建退出事件失败（不影响单实例）：{ex.Message}"); }

        Log.Info($"单实例检查: IsFirst={IsFirst}");
    }

    /// <summary>
    /// 通知已在运行的实例。重复双击 → 唤起宠物；带 <c>--exit</c> 启动 → 让它退出。
    /// 后者让「退出」不必非得去点托盘菜单，脚本/卸载时也用得上。
    /// </summary>
    public void SignalExisting(bool exitInsteadOfShow = false)
    {
        try
        {
            if (exitInsteadOfShow) s_exitEvent?.Set();
            else s_showEvent?.Set();
        }
        catch (Exception ex) { Log.Warn($"通知已有实例失败: {ex.Message}"); }
    }

    /// <summary>由第一个实例调用：等两个事件里的任意一个（单个线程，WaitAny）。</summary>
    public void ListenForSignals(Action onShow, Action onExit)
    {
        var handles = new List<WaitHandle>();
        if (s_showEvent is not null) handles.Add(s_showEvent);
        if (s_exitEvent is not null) handles.Add(s_exitEvent);
        if (handles.Count == 0) return;

        var arr = handles.ToArray();
        var t = new Thread(() =>
        {
            while (true)
            {
                try
                {
                    var i = WaitHandle.WaitAny(arr);
                    if (ReferenceEquals(arr[i], s_showEvent)) onShow();
                    else onExit();
                }
                catch (Exception ex)
                {
                    Log.Warn($"等待信号异常: {ex.Message}");
                    break;
                }
            }
        })
        { IsBackground = true, Name = "DeepSeekPet.Signals" };
        t.Start();
    }

    public void Dispose()
    {
        try { s_mutex?.ReleaseMutex(); } catch { }
        s_mutex?.Dispose();
        s_mutex = null;
    }
}
