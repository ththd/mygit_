using System.Drawing;
using System.Windows;
using System.Windows.Interop;
using DeepSeekPet.Diagnostics;
using Screen = System.Windows.Forms.Screen;

namespace DeepSeekPet.Interop;

/// <summary>
/// 屏幕几何。设计上的关键取舍：<b>全部在物理像素空间作业</b>，
/// 位置一律用 GetWindowRect 读、SetWindowPos 写，不碰 WPF 的 Window.Left/Top。
///
/// 原因：Window.Left/Top 是 DIP，Screen.WorkingArea 是物理像素，混合显示器 + 缩放
/// 下两者的换算极易出错（这是本项目原本的头号风险）。直接走 Win32 物理像素可完全绕开。
/// 前提是 app.manifest 里声明了 PerMonitorV2，否则 WorkingArea 本身就不是真实物理像素。
/// </summary>
internal static class MonitorHelper
{
    /// <summary>松手位置上距边缘多少物理像素以内才吸附。太大会变得“到处乱吸”。</summary>
    private const int SnapTolerancePx = 48;

    public static Screen ScreenOf(IntPtr hwnd)
    {
        if (hwnd != IntPtr.Zero)
        {
            try { return Screen.FromHandle(hwnd); }
            catch (Exception ex) { Log.Warn($"Screen.FromHandle 失败: {ex.Message}"); }
        }
        return Screen.PrimaryScreen ?? Screen.AllScreens[0];
    }

    public static Rectangle WorkAreaOf(IntPtr hwnd)
    {
        try { return ScreenOf(hwnd).WorkingArea; }
        catch (Exception ex)
        {
            Log.Error("取工作区失败", ex);
            return Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        }
    }

    /// <summary>
    /// 吸附：若窗口任一边在容差内贴近工作区边缘，就贴上去；同时把另一轴夹紧，
    /// 保证整只宠物（含下方余额条）始终完整落在工作区内。
    /// 容差外则只做夹紧，不强行吸附（拖到屏幕中间就留在中间）。
    /// </summary>
    public static void SnapToNearestEdge(IntPtr hwnd)
    {
        if (hwnd == IntPtr.Zero) return;

        var wr = NativeMethods.GetRect(hwnd);
        var wa = WorkAreaOf(hwnd);
        if (wr.Width <= 0 || wr.Height <= 0) return;

        int newX = wr.Left;
        int newY = wr.Top;

        int dLeft = wr.Left - wa.Left;
        int dRight = wa.Right - wr.Right;
        int dTop = wr.Top - wa.Top;
        int dBottom = wa.Bottom - wr.Bottom;

        // 找最近的一条边，且必须在容差内
        int nearest = Math.Min(Math.Min(dLeft, dRight), Math.Min(dTop, dBottom));
        if (nearest <= SnapTolerancePx)
        {
            if (nearest == dLeft) newX = wa.Left;
            else if (nearest == dRight) newX = wa.Right - wr.Width;
            else if (nearest == dTop) newY = wa.Top;
            else newY = wa.Bottom - wr.Height;
        }

        // 另一轴夹紧，防止窗口有部分跑到工作区外（比如任务栏那一侧）
        newX = Math.Clamp(newX, wa.Left, Math.Max(wa.Left, wa.Right - wr.Width));
        newY = Math.Clamp(newY, wa.Top, Math.Max(wa.Top, wa.Bottom - wr.Height));

        if (newX != wr.Left || newY != wr.Top)
        {
            NativeMethods.MoveWindowPixels(hwnd, newX, newY);
            Log.Info($"吸附: ({wr.Left},{wr.Top}) -> ({newX},{newY})");
        }
    }

    /// <summary>该物理像素矩形是否与任一显示器的工作区相交。</summary>
    public static bool IsOnAnyScreen(Rectangle rect)
    {
        foreach (var s in Screen.AllScreens)
        {
            if (s.WorkingArea.IntersectsWith(rect)) return true;
        }
        return false;
    }

    /// <summary>主屏工作区右下角的默认位置（物理像素），留一点内边距。
    /// 返回元组而非 Point —— System.Drawing.Point 与 System.Windows.Point 会二义。</summary>
    public static (int X, int Y) DefaultPositionPx(int winW, int winH)
    {
        var wa = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        const int margin = 24;
        // 靠底、略偏右：桌宠的常规站位
        int x = wa.Right - winW - margin;
        int y = wa.Bottom - winH - margin;
        x = Math.Clamp(x, wa.Left, Math.Max(wa.Left, wa.Right - winW));
        y = Math.Clamp(y, wa.Top, Math.Max(wa.Top, wa.Bottom - winH));
        return (x, y);
    }

    /// <summary>主显示器的设备名（用于记住宠物在哪块屏上）。</summary>
    public static string CurrentMonitorName(IntPtr hwnd)
    {
        try { return ScreenOf(hwnd).DeviceName; }
        catch { return string.Empty; }
    }

    public static IntPtr HandleOf(Window w)
    {
        try { return new WindowInteropHelper(w).Handle; }
        catch { return IntPtr.Zero; }
    }
}
