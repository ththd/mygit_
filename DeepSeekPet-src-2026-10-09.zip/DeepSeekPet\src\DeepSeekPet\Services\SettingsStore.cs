using DeepSeekPet.Diagnostics;

namespace DeepSeekPet.Services;

internal sealed class WindowSettings
{
    /// <summary>记住的位置，<b>物理像素</b>（与 MonitorHelper 的坐标空间一致）。</summary>
    public int? Left { get; set; }
    public int? Top { get; set; }
    /// <summary>记住当时在哪块显示器上（DeviceName，如 \\.\DISPLAY1）。</summary>
    public string MonitorDeviceName { get; set; } = "";
}

internal sealed class BalanceSettings
{
    public string PreferredCurrency { get; set; } = "CNY";
    public decimal LowBalanceThreshold { get; set; } = 10m;
    public int RefreshSeconds { get; set; } = 60;
}

internal sealed class TraySettings
{
    public bool ShowBalloonOnLowBalance { get; set; } = true;
}

/// <summary>
/// 互动动效开关。除眨眼外全部默认 true —— 动效是特性本身，默认就该看得见；
/// 「本机无法运行验收」这个风险靠<b>可关闭</b>兜底，而不是靠默认关掉。
/// </summary>
internal sealed class AnimationSettings
{
    /// <summary>总开关。关掉后不再注册任何额外计时器，空闲 CPU 回到未加动效时的水平。</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// 待机眨眼，默认<b>关闭</b>。
    /// 实测（DeepSeekPet-tools\check-sprites.ps1）base 与 blink_* 的平均色差为
    /// 11.2–13.4、20–24% 的不透明像素差超过 8，且 blink_closed 比 base 多了一层腮红 ——
    /// 它们不是同一批次的动画序列帧，换帧读起来像「宠物变了个样」而非「眨眼」。
    /// 素材本身没问题，只是不适合当眨眼序列。想试可以打开。
    /// </summary>
    public bool Blink { get; set; } = false;

    /// <summary>悬停、按住、单击的反应。</summary>
    public bool Reactions { get; set; } = true;

    /// <summary>余额涨跌与跌破阈值时的情绪反应。</summary>
    public bool BalanceMood { get; set; } = true;
}

internal sealed class AppSettings
{
    public int Version { get; set; } = 2;
    public WindowSettings Window { get; set; } = new();
    public BalanceSettings Balance { get; set; } = new();
    public TraySettings Tray { get; set; } = new();
    public AnimationSettings Animation { get; set; } = new();
}

/// <summary>
/// %APPDATA%\DeepSeekPet\settings.json。绝不写 exe 旁边 ——
/// 单文件发布后那个目录是解包到临时目录的，可能只读且位置不固定。
/// 本文件不含任何机密（API Key 只存在于 DPAPI 密文里）。
/// </summary>
internal sealed class SettingsStore
{
    private static readonly string Dir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DeepSeekPet");

    private static readonly string FilePath = Path.Combine(Dir, "settings.json");

    private static readonly JsonSerializerOptions Opts = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    };

    public static string SettingsPath => FilePath;

    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return new AppSettings();
            var json = File.ReadAllText(FilePath);
            return Normalize(JsonSerializer.Deserialize<AppSettings>(json, Opts));
        }
        catch (Exception ex)
        {
            // 配置损坏绝不能把程序搞崩：备份一份再回到默认值
            Log.Error("settings.json 解析失败，已备份并重置", ex);
            try
            {
                var bak = FilePath + ".bak";
                if (File.Exists(bak)) File.Delete(bak);
                File.Move(FilePath, bak);
            }
            catch { /* 备份失败就算了 */ }
            return new AppSettings();
        }
    }

    /// <summary>
    /// System.Text.Json 遇到 JSON 里显式的 <c>"Animation": null</c> 时会把属性置空
    /// （初始化器被忽略）—— 手改配置很容易踩到，这里兜底回默认值。
    /// 键<b>缺失</b>则不受影响：反序列化不会调 setter，属性保留初始化值，旧配置天然可用。
    /// </summary>
    private static AppSettings Normalize(AppSettings? s)
    {
        if (s is null) return new AppSettings();
        s.Window ??= new WindowSettings();
        s.Balance ??= new BalanceSettings();
        s.Tray ??= new TraySettings();
        s.Animation ??= new AnimationSettings();
        return s;
    }

    public void Save(AppSettings s)
    {
        try
        {
            Directory.CreateDirectory(Dir);
            var json = JsonSerializer.Serialize(s, Opts);
            var tmp = FilePath + ".tmp";
            File.WriteAllText(tmp, json);

            if (File.Exists(FilePath)) File.Replace(tmp, FilePath, null);
            else File.Move(tmp, FilePath);
        }
        catch (Exception ex) { Log.Error("保存 settings.json 失败", ex); }
    }
}
