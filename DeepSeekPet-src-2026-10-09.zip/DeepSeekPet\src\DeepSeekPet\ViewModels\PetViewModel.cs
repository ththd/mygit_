using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using DeepSeekPet.Models;

namespace DeepSeekPet.ViewModels;

/// <summary>手写的 INotifyPropertyChanged。不引 MVVM 框架 —— 一共就五个属性。</summary>
internal sealed class PetViewModel : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    private string _balanceText = "—";
    private string _statusText = "准备中…";
    private bool _isError;
    private bool _isLoading = true;   // 首帧就是「还没有数据」，不是「出错」
    private bool _isLow;

    public string BalanceText { get => _balanceText; private set => Set(ref _balanceText, value); }
    public string StatusText { get => _statusText; private set => Set(ref _statusText, value); }
    public bool IsError { get => _isError; private set => Set(ref _isError, value); }
    public bool IsLoading { get => _isLoading; private set => Set(ref _isLoading, value); }
    public bool IsLow { get => _isLow; private set => Set(ref _isLow, value); }

    public void Apply(BalanceSnapshot snap, bool isLow)
    {
        IsLoading = false;
        IsLow = isLow;
        IsError = snap.HasError;

        if (snap.HasError)
        {
            // 未配置 Key 时显示明确的文字，而不是一个破折号 ——
            // 用户关掉首跑引导窗后，只剩「红点 + —」的话看起来就像坏了。
            BalanceText = snap.Error == BalanceErrorKind.NoApiKey ? "未设置" : "—";
            StatusText = BalanceErrorMessages.ToUserString(snap.Error);
            return;
        }

        // decimal 格式化，且用 InvariantCulture 保证小数点是 "." 而不是随系统变
        BalanceText = $"{snap.Symbol}{snap.Total.ToString("0.00", CultureInfo.InvariantCulture)}";
        StatusText = $"更新于 {snap.FetchedAt.LocalDateTime:HH:mm:ss}";
    }

    private void Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
