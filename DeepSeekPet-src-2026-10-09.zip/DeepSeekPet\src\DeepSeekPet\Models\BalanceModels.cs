using System.Globalization;

namespace DeepSeekPet.Models;

/// <summary>DeepSeek GET /user/balance 的原始响应。
/// 注意：金额字段在 JSON 里是<b>字符串</b>不是数字（"110.00"），这里保持 string，
/// 解析统一走 BalanceParser，避免任何 double/float 介入。</summary>
internal sealed record BalanceResponse(
    [property: JsonPropertyName("is_available")] bool IsAvailable,
    [property: JsonPropertyName("balance_infos")] List<BalanceEntry>? BalanceInfos);

internal sealed record BalanceEntry(
    [property: JsonPropertyName("currency")] string? Currency,
    [property: JsonPropertyName("total_balance")] string? TotalBalance,
    [property: JsonPropertyName("granted_balance")] string? GrantedBalance,
    [property: JsonPropertyName("topped_up_balance")] string? ToppedUpBalance);

internal enum BalanceErrorKind
{
    None,
    NoApiKey,
    Unauthorized,
    InsufficientBalance,
    InvalidFormat,
    InvalidParams,
    RateLimited,
    ServerError,
    NetworkError,
    Timeout,
    DecodeError,
}

/// <summary>一次查询的结果。预期内的失败也走这里（不抛异常），让 UI 和托盘总有东西可渲染。</summary>
internal sealed record BalanceSnapshot(
    bool IsAvailable,
    string Currency,
    decimal Total,
    decimal Granted,
    decimal ToppedUp,
    DateTimeOffset FetchedAt,
    BalanceErrorKind Error,
    string? ErrorMessage)
{
    public bool HasError => Error != BalanceErrorKind.None;

    public string Symbol => Currency switch
    {
        "CNY" => "¥",
        "USD" => "$",
        _ => "",
    };

    public static BalanceSnapshot Failure(BalanceErrorKind kind, string? message = null) =>
        new(false, "CNY", 0m, 0m, 0m, DateTimeOffset.Now, kind, message);
}

internal static class BalanceParser
{
    /// <summary>金额解析。必须 InvariantCulture —— 本机可能跑在 zh-CN 下，
    /// 用 CurrentCulture 解析 "110.00" 有踩坑风险，且绝不能用 float/double。</summary>
    public static bool TryParseAmount(string? s, out decimal value) =>
        decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out value);

    /// <summary>balance_infos 是数组（每币种一项）。优先取偏好币种，其次第一项，都没有则 null。</summary>
    public static BalanceEntry? SelectEntry(IList<BalanceEntry>? infos, string preferred = "CNY")
    {
        if (infos is null || infos.Count == 0) return null;
        foreach (var e in infos)
        {
            if (string.Equals(e.Currency, preferred, StringComparison.OrdinalIgnoreCase))
                return e;
        }
        return infos[0];
    }

    /// <summary>把原始响应转成快照。任何解析失败都归为 DecodeError，不抛。</summary>
    public static BalanceSnapshot ToSnapshot(BalanceResponse resp, string preferred = "CNY")
    {
        if (resp.BalanceInfos is null || resp.BalanceInfos.Count == 0)
            return BalanceSnapshot.Failure(BalanceErrorKind.DecodeError, "响应里没有 balance_infos");

        var entry = SelectEntry(resp.BalanceInfos, preferred);
        if (entry is null)
            return BalanceSnapshot.Failure(BalanceErrorKind.DecodeError, "未能选出币种条目");

        if (!TryParseAmount(entry.TotalBalance, out var total) ||
            !TryParseAmount(entry.GrantedBalance, out var granted) ||
            !TryParseAmount(entry.ToppedUpBalance, out var topped))
        {
            return BalanceSnapshot.Failure(BalanceErrorKind.DecodeError,
                $"金额字段无法按 decimal 解析: total='{entry.TotalBalance}' granted='{entry.GrantedBalance}' topped='{entry.ToppedUpBalance}'");
        }

        return new BalanceSnapshot(
            resp.IsAvailable,
            entry.Currency ?? preferred,
            total, granted, topped,
            DateTimeOffset.Now,
            BalanceErrorKind.None,
            null);
    }
}

internal static class BalanceErrorMessages
{
    public static string ToUserString(BalanceErrorKind kind) => kind switch
    {
        BalanceErrorKind.None => "正常",
        BalanceErrorKind.NoApiKey => "未设置 API Key",
        BalanceErrorKind.Unauthorized => "API Key 无效",
        BalanceErrorKind.InsufficientBalance => "余额不足",
        BalanceErrorKind.InvalidFormat => "请求格式错误",
        BalanceErrorKind.InvalidParams => "参数错误",
        BalanceErrorKind.RateLimited => "请求过于频繁",
        BalanceErrorKind.ServerError => "服务端错误",
        BalanceErrorKind.NetworkError => "网络不通",
        BalanceErrorKind.Timeout => "请求超时",
        BalanceErrorKind.DecodeError => "响应解析失败",
        _ => "未知错误",
    };
}
