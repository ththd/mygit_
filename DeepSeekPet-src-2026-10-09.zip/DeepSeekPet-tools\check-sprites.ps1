# Static checks on the shipped sprites. Runs without launching the app, which
# matters because Smart App Control blocks every freshly built local assembly
# on this machine -- so image analysis is one of the few real verification
# channels available here.
#
#   1. Alpha bounding box + margin to each canvas edge. The pet window can only
#      translate UP safely: these sprites are bust crops whose opaque content is
#      flush with the right and bottom edges, so any rightward/downward motion
#      clips the character.
#   2. For the blink frames: how far they actually differ from base.png. They
#      are NOT a true animation sequence (different art batch), so if the mean
#      colour delta is large the blink will read as "the pet changed" rather
#      than "the pet blinked".
#
# ASCII-only on purpose: PS 5.1 reads .ps1 with the ANSI codepage when no BOM.
param(
  [string]$Dir = "C:\Users\lenovo\DeepSeekPet\src\DeepSeekPet\Assets\Sprites"
)

Add-Type -AssemblyName System.Drawing

function Get-Img([string]$path) {
  $bmp = New-Object System.Drawing.Bitmap $path
  $w = $bmp.Width; $h = $bmp.Height
  $rect = New-Object System.Drawing.Rectangle(0, 0, $w, $h)
  $data = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly,
                        [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $stride = $data.Stride
  $bytes = New-Object byte[] ($stride * $h)
  [System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $bytes, 0, $bytes.Length)
  $bmp.UnlockBits($data); $bmp.Dispose()
  # LockBits with Format32bppArgb yields BGRA byte order, little-endian:
  #   i = B, i+1 = G, i+2 = R, i+3 = A
  return [pscustomobject]@{ B = $bytes; S = $stride; W = $w; H = $h }
}

function Get-Bbox($img) {
  $b = $img.B; $s = $img.S; $w = $img.W; $h = $img.H
  $minX = $w; $minY = $h; $maxX = -1; $maxY = -1
  for ($y = 0; $y -lt $h; $y++) {
    $row = $y * $s
    for ($x = 0; $x -lt $w; $x++) {
      if ($b[$row + $x * 4 + 3] -gt 8) {
        if ($x -lt $minX) { $minX = $x }
        if ($x -gt $maxX) { $maxX = $x }
        if ($y -lt $minY) { $minY = $y }
        if ($y -gt $maxY) { $maxY = $y }
      }
    }
  }
  return [pscustomobject]@{ minX = $minX; minY = $minY; maxX = $maxX; maxY = $maxY }
}

function Compare-Img($a, $cmp) {
  $ba = $a.B; $bb = $cmp.B; $s = $a.S; $w = $a.W; $h = $a.H
  $n = 0; $sum = 0.0; $max = 0; $over8 = 0
  for ($y = 0; $y -lt $h; $y++) {
    $row = $y * $s
    for ($x = 0; $x -lt $w; $x++) {
      $i = $row + $x * 4
      if ($ba[$i + 3] -gt 8 -and $bb[$i + 3] -gt 8) {
        $d = ([math]::Abs($ba[$i] - $bb[$i]) +
              [math]::Abs($ba[$i + 1] - $bb[$i + 1]) +
              [math]::Abs($ba[$i + 2] - $bb[$i + 2])) / 3.0
        $n++; $sum += $d
        if ($d -gt $max) { $max = $d }
        if ($d -gt 8) { $over8++ }
      }
    }
  }
  if ($n -eq 0) { return $null }
  return [pscustomobject]@{
    Pixels = $n; Mean = $sum / $n; Max = $max; OverPct = 100.0 * $over8 / $n
  }
}

$all = @{}
$names = @(
  "base.png",
  "expressions\exhausted.png", "expressions\angry.png",
  "expressions\shy.png", "expressions\press.png", "expressions\disappointed.png",
  "blink\blink_half_open.png", "blink\blink_half.png", "blink\blink_closed.png"
)

Write-Output "=== 1. alpha bbox / margins (px; canvas 360) ==="
foreach ($n in $names) {
  $p = Join-Path $Dir $n
  if (-not (Test-Path $p)) { Write-Output ("MISSING {0}" -f $n); continue }
  $img = Get-Img $p
  $bb = Get-Bbox $img
  $all[$n] = $img
  Write-Output ("{0,-34} bbox=({1,3},{2,3})-({3,3},{4,3})  margin  L={5,3} R={6,3} T={7,3} B={8,3}  => safe-up={9:N1} DIP" -f `
    $n, $bb.minX, $bb.minY, $bb.maxX, $bb.maxY,
    $bb.minX, ($img.W - 1 - $bb.maxX), $bb.minY, ($img.H - 1 - $bb.maxY),
    ($bb.minY * 0.5))
}

Write-Output ""
Write-Output "=== 2. blink frames vs base.png (opaque pixels only) ==="
$base = $all["base.png"]
if ($base -ne $null) {
  foreach ($n in @("blink\blink_half_open.png", "blink\blink_half.png", "blink\blink_closed.png")) {
    if ($all[$n] -eq $null) { continue }
    $r = Compare-Img $base $all[$n]
    if ($r -eq $null) { Write-Output ("{0,-34} no overlap" -f $n); continue }
    Write-Output ("{0,-34} mean={1,6:N2}  max={2,6:N1}  pixels>8: {3,5:N1}%  (n={4})" -f `
      $n, $r.Mean, $r.Max, $r.OverPct, $r.Pixels)
  }
}
