using System.Runtime.InteropServices;
using DeepSeekPet.Diagnostics;

namespace DeepSeekPet.Interop;

/// <summary>
/// Win32 互操作。这里的东西都是桌面宠物绕不开的：
///  - 隐藏 Alt+Tab 条目（WPF 没有对应属性）
///  - 直接在<b>物理像素</b>空间定位/读取窗口，从而完全绕开 WPF 的 DIP 换算
/// </summary>
internal static class NativeMethods
{
    public const int GWL_EXSTYLE = -20;
    public const int WS_EX_TOOLWINDOW = 0x00000080;
    public const int WS_EX_APPWINDOW = 0x00040000;

    public static readonly IntPtr HWND_TOP = IntPtr.Zero;
    public const uint SWP_NOSIZE = 0x0001;
    public const uint SWP_NOMOVE = 0x0002;
    public const uint SWP_NOZORDER = 0x0004;
    public const uint SWP_NOACTIVATE = 0x0010;
    public const uint SWP_FRAMECHANGED = 0x0020;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left, Top, Right, Bottom;
        public int Width => Right - Left;
        public int Height => Bottom - Top;
    }

    // 32 位 user32 没有 SetWindowLongPtr/GetWindowLongPtr 导出 —— 必须按指针宽度分派，
    // 否则 32 位进程会 EntryPointNotFoundException。
    [DllImport("user32.dll", EntryPoint = "GetWindowLong", SetLastError = true)]
    private static extern IntPtr GetWindowLong32(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtr", SetLastError = true)]
    private static extern IntPtr GetWindowLongPtr64(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll", EntryPoint = "SetWindowLong", SetLastError = true)]
    private static extern IntPtr SetWindowLong32(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtr", SetLastError = true)]
    private static extern IntPtr SetWindowLongPtr64(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
        int X, int Y, int cx, int cy, uint uFlags);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    private static IntPtr GetWindowLongPtrSafe(IntPtr hWnd, int nIndex) =>
        IntPtr.Size == 8 ? GetWindowLongPtr64(hWnd, nIndex) : GetWindowLong32(hWnd, nIndex);

    private static IntPtr SetWindowLongPtrSafe(IntPtr hWnd, int nIndex, IntPtr value)
    {
        // Win32 的 SetWindowLong 成功时不清理 last-error，所以必须先置 0 才能区分“返回 0 是失败还是真值 0”。
        Marshal.SetLastPInvokeError(0);
        var result = IntPtr.Size == 8
            ? SetWindowLongPtr64(hWnd, nIndex, value)
            : SetWindowLong32(hWnd, nIndex, value);
        if (result == IntPtr.Zero)
        {
            var err = Marshal.GetLastWin32Error();
            if (err != 0) Log.Warn($"SetWindowLongPtr 失败, Win32Error={err}");
        }
        return result;
    }

    /// <summary>
    /// 加 WS_EX_TOOLWINDOW、去掉 WS_EX_APPWINDOW。这是把窗口从 Alt+Tab 和任务栏
    /// 彻底摘掉的<b>唯一可靠</b>办法 —— ShowInTaskbar=false 只保证任务栏按钮，
    /// 对 Alt+Tab 无契约保证。
    /// 必须在 HWND 已创建、且窗口尚未激活时调用（OnSourceInitialized）。
    /// </summary>
    public static void HideFromAltTab(IntPtr hwnd)
    {
        if (hwnd == IntPtr.Zero) return;

        var ex = GetWindowLongPtrSafe(hwnd, GWL_EXSTYLE).ToInt64();
        ex |= WS_EX_TOOLWINDOW;
        ex &= ~WS_EX_APPWINDOW;
        SetWindowLongPtrSafe(hwnd, GWL_EXSTYLE, new IntPtr(ex));

        // 某些窗口样式被系统缓存，改完补一次 SWP_FRAMECHANGED 让它立即生效。
        SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
    }

    /// <summary>取窗口的物理像素矩形（屏幕坐标系）。</summary>
    public static RECT GetRect(IntPtr hwnd)
    {
        if (!GetWindowRect(hwnd, out var r))
            Log.Warn($"GetWindowRect 失败, Win32Error={Marshal.GetLastWin32Error()}");
        return r;
    }

    /// <summary>用物理像素移动窗口。不激活窗口、不改尺寸、不动 z-order。</summary>
    public static void MoveWindowPixels(IntPtr hwnd, int x, int y)
    {
        if (!SetWindowPos(hwnd, HWND_TOP, x, y, 0, 0,
                SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE))
        {
            Log.Warn($"SetWindowPos 失败, Win32Error={Marshal.GetLastWin32Error()}");
        }
    }
}
