using DeepSeekPet.Models;

namespace DeepSeekPet.Services;

/// <summary>
/// 抽这一层是为了让 FakeBalanceClient 能在<b>没有真 API Key、没有网络</b>的情况下
/// 跑通全部三个功能 —— 这是本项目验证策略的核心。
/// </summary>
internal interface IBalanceClient
{
    /// <summary>
    /// 是否必须先有 API Key 才能发起请求。
    /// 真客户端当然要；假客户端不要 —— 否则「首次运行没有 Key」这条短路
    /// 会让 <see cref="FakeBalanceClient"/> 永远不被调用，离线验证就无从谈起。
    /// 这是客户端自身的能力声明，不是外部塞进来的测试开关。
    /// </summary>
    bool RequiresApiKey => true;

    Task<BalanceSnapshot> GetAsync(string apiKey, CancellationToken ct);
}
