using System.Windows.Media.Imaging;
using DeepSeekPet.Diagnostics;

namespace DeepSeekPet.Animation;

/// <summary>
/// 精灵图的持有者。素材以 Resource 嵌入，走 pack:// URI 加载 ——
/// 这样单文件发布也不会因为 Assembly.Location 为空而找不到文件。
///
/// 素材是 360×360（已在构建前离线降采样，原始 610×610 约 250–340KB/张）。
/// 取 360 而非 180：桌宠框是 180 DIP，而本机为 200% 缩放，
/// 180 DIP 正好等于 360 物理像素 —— 360px 素材在屏上是 1:1，既不放大也不重采样。
/// 全部 OnLoad + Freeze：解码只发生一次，且可跨线程使用。
///
/// <b>两张加载路径是刻意分开的：</b>
/// 三张核心图（base / exhausted / angry）是「桌宠长什么样」的底线，
/// 缺了就该启动失败（走 <see cref="LoadFrozen"/> 直接抛）；
/// 而互动表情是锦上添花 —— 缺一张只该少一个反应，不该让整个程序起不来
/// （走 <see cref="TryLoadFrozen"/>，记 Warn 后返回 null，由调用方降级）。
/// 这也让「代码先落地、素材后到」成为可行的开发顺序。
/// </summary>
internal sealed class SpriteSet
{
    public BitmapSource Base { get; private init; } = null!;
    public BitmapSource Exhausted { get; private init; } = null!;
    public BitmapSource Angry { get; private init; } = null!;

    /// <summary>悬停害羞。缺失时悬停反应自动降级为「只动效不换图」。</summary>
    public BitmapSource? Shy { get; private init; }

    /// <summary>按住 / 睡着时的闭眼平静脸。缺失时这两个场景整体禁用。</summary>
    public BitmapSource? Press { get; private init; }

    /// <summary>哭脸，只在跌破阈值那一刻用。</summary>
    public BitmapSource? Disappointed { get; private init; }

    /// <summary>
    /// 眨眼帧序列（半开 → 半闭 → 全闭）。空列表表示素材缺失，眨眼自动关闭。
    /// 顺序即播放顺序，由 <see cref="SpriteAnimator"/> 决定每帧停留多久。
    /// </summary>
    public IReadOnlyList<BitmapSource> BlinkFrames { get; private init; } = Array.Empty<BitmapSource>();

    public static SpriteSet Load()
    {
        var blink = new List<BitmapSource>();
        foreach (var name in new[] { "blink_half_open.png", "blink_half.png", "blink_closed.png" })
        {
            if (TryLoadFrozen($"Assets/Sprites/blink/{name}") is { } frame) blink.Add(frame);
        }

        // 眨眼必须是完整序列：只有一两帧就切进去，会停在「半闭」上不回来，
        // 比不眨眼糟糕得多。宁可整组丢弃。
        if (blink.Count != 3)
        {
            if (blink.Count > 0)
                Log.Warn($"眨眼帧只加载到 {blink.Count}/3 张，整组停用（序列不完整会卡在半闭状态）");
            blink.Clear();
        }

        return new SpriteSet
        {
            Base = LoadFrozen("Assets/Sprites/base.png"),
            Exhausted = LoadFrozen("Assets/Sprites/expressions/exhausted.png"),
            Angry = LoadFrozen("Assets/Sprites/expressions/angry.png"),

            Shy = TryLoadFrozen("Assets/Sprites/expressions/shy.png"),
            Press = TryLoadFrozen("Assets/Sprites/expressions/press.png"),
            Disappointed = TryLoadFrozen("Assets/Sprites/expressions/disappointed.png"),
            BlinkFrames = blink,
        };
    }

    private static BitmapSource LoadFrozen(string relativePath) =>
        LoadCore(relativePath) ?? throw new InvalidOperationException($"核心精灵图缺失：{relativePath}");

    /// <summary>缺文件返回 null（记 Warn），供可选素材使用。</summary>
    private static BitmapSource? TryLoadFrozen(string relativePath)
    {
        var bmp = LoadCore(relativePath);
        if (bmp is null) Log.Warn($"可选精灵图缺失，相关动效将自动降级：{relativePath}");
        return bmp;
    }

    private static BitmapSource? LoadCore(string relativePath)
    {
        var uri = new Uri($"pack://application:,,,/{relativePath}", UriKind.Absolute);
        var info = Application.GetResourceStream(uri);
        if (info is null) return null;

        using var stream = info.Stream;
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.StreamSource = stream;
        bmp.CacheOption = BitmapCacheOption.OnLoad; // 立刻解码完，不持有文件流
        bmp.EndInit();
        bmp.Freeze();
        Log.Info($"精灵已加载: {relativePath} ({bmp.PixelWidth}x{bmp.PixelHeight})");
        return bmp;
    }

    /// <summary>
    /// 把 <see cref="PetExpression"/> 映射到实际位图。返回 null 表示该表情的素材缺失，
    /// 调用方应退回基线图 —— 这样「少一张素材」不会变成「白屏」。
    /// </summary>
    public BitmapSource? ImageOf(PetExpression expression) => expression switch
    {
        PetExpression.Base => Base,
        PetExpression.Exhausted => Exhausted,
        PetExpression.Angry => Angry,
        PetExpression.Shy => Shy,
        PetExpression.Press => Press,
        PetExpression.Disappointed => Disappointed,
        PetExpression.BlinkHalfOpen => BlinkFrames.Count > 0 ? BlinkFrames[0] : null,
        PetExpression.BlinkHalf => BlinkFrames.Count > 1 ? BlinkFrames[1] : null,
        PetExpression.BlinkClosed => BlinkFrames.Count > 2 ? BlinkFrames[2] : null,
        _ => null,
    };
}
