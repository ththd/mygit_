# Desktop-pet screenshot tool: launch -> wait -> capture the window region in
# true PHYSICAL pixels -> save PNG -> exit.
# PowerShell 5.1 is DPI-unaware by default, so this thread must first switch to
# PER_MONITOR_AWARE_V2; otherwise GetWindowRect/CopyFromScreen return coordinates
# virtualized by the monitor scale factor and the crop lands in the wrong place.
# NOTE: keep this file ASCII-only. PS 5.1 reads .ps1 using the ANSI codepage when
# there is no BOM, so non-ASCII text gets mangled and breaks the parser.
param(
  [string]$Out       = "C:\Users\lenovo\DeepSeekPet-tools\shot.png",
  [string]$Balance   = "110.00",
  [string]$ErrorKind = "",
  [int]$WaitSec      = 7,
  [int]$Margin       = 24,
  [switch]$AllWindows,
  [switch]$CloseDialogs,
  [switch]$KeepLog
)

Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;using System.Collections.Generic;using System.Runtime.InteropServices;
public class Cap {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EProc cb, IntPtr p);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out R r);
  [DllImport("user32.dll")] public static extern IntPtr GetWindowLongPtr(IntPtr h,int i);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  public delegate bool EProc(IntPtr h, IntPtr p);
  [StructLayout(LayoutKind.Sequential)] public struct R { public int L,T,Rt,B; }
  public static List<IntPtr> ForPid(uint t) {
    var f = new List<IntPtr>();
    EnumWindows((h,p)=>{ uint pid; GetWindowThreadProcessId(h,out pid);
      if (pid==t && IsWindowVisible(h)) f.Add(h); return true; }, IntPtr.Zero);
    return f;
  }
}
"@

[void][Cap]::SetThreadDpiAwarenessContext([IntPtr](-4))   # PER_MONITOR_AWARE_V2

$log = "$env:LOCALAPPDATA\DeepSeekPet\log.txt"
if (-not $KeepLog) { [System.IO.File]::WriteAllText($log, "") }

$env:DEEPSEEPET_FAKE_BALANCE  = $Balance
$env:DEEPSEEPET_FAKE_ERROR    = $ErrorKind
$env:DEEPSEEPET_FAKE_DELAY_MS = $null

$exe = "C:\Users\lenovo\DeepSeekPet\src\DeepSeekPet\bin\Debug\net10.0-windows\DeepSeekPet.exe"
$p = Start-Process $exe -PassThru
Start-Sleep -Seconds $WaitSec

$wins = [Cap]::ForPid([uint32]$p.Id)

# The settings dialog is CenterOwner, so it always sits on top of the pet and a
# screen grab of the pet's rect would return the dialog's pixels instead. The pet
# is the only WS_EX_LAYERED (0x80000) window, so closing non-layered ones isolates it.
if ($CloseDialogs) {
  foreach ($h in $wins) {
    $ex = [Cap]::GetWindowLongPtr($h, -20).ToInt64()
    if (($ex -band 0x80000) -eq 0) { [void][Cap]::PostMessage($h, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) }
  }
  Start-Sleep -Milliseconds 1500
  $wins = [Cap]::ForPid([uint32]$p.Id)
}

if (-not $wins -or $wins.Count -eq 0) {
  Write-Output "!! no visible window found"
  Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
  exit 1
}
if (-not $AllWindows) { $wins = @($wins[0]) }
Write-Output "visible windows: $($wins.Count)"

$idx = 0
foreach ($h in $wins) {
  $r = New-Object Cap+R
  [void][Cap]::GetWindowRect($h, [ref]$r)
  $w = $r.Rt - $r.L; $h2 = $r.B - $r.T
  if ($w -le 0 -or $h2 -le 0) { continue }

  $target = if ($idx -eq 0) { $Out } else {
    [System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($Out),
      [System.IO.Path]::GetFileNameWithoutExtension($Out) + "_$idx" + [System.IO.Path]::GetExtension($Out))
  }
  Write-Output "window[$idx] rect=($($r.L),$($r.T)) ${w}x${h2} -> $target"

  $bmp = New-Object System.Drawing.Bitmap(($w + 2*$Margin), ($h2 + 2*$Margin))
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.CopyFromScreen(($r.L - $Margin), ($r.T - $Margin), 0, 0, $bmp.Size)
  $g.Dispose()
  $bmp.Save($target, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  $idx++
}

Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 400
Write-Output "--- log ---"
Get-Content $log | Where-Object { $_ -match 'Fake|refresh' } | Select-Object -Last 10
