# run-selfcheck.ps1
#
# Runs the desk pet's pure-logic assertions. ASCII only on purpose: PowerShell 5.1
# reads .ps1 files using the ANSI code page unless they carry a BOM, so any
# non-ASCII character here would be mangled into a parse error.
#
# WHY NOT JUST RUN THE APP?  Smart App Control is in enforce mode on this machine
# and blocks every freshly built, unsigned assembly that the dotnet host tries to
# load (exit code 0xE0434352, CodeIntegrity event 3077). But PowerShell 5.1 loading
# an assembly via LoadFrom is NOT blocked -- verified empirically. So the pure-logic
# layer is built as a net48 library (the framework PowerShell 5.1 can load natively)
# and executed right here.
#
# This is not a simulation: SelfCheck.csproj <Compile Include>s the real shipped
# source files for PetStateMachine / BalanceMoodTracker / BalanceModels.

[CmdletBinding()]
param(
    [string]$ProjectDir = "C:\Users\lenovo\DeepSeekPet-tools\selfcheck",
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"

$proj = Join-Path $ProjectDir "SelfCheck.csproj"
$dll  = Join-Path $ProjectDir "bin\Debug\net48\SelfCheck.dll"

if (-not $SkipBuild) {
    Write-Host "building ..." -ForegroundColor Cyan
    $out = & dotnet build $proj -v q --nologo 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "BUILD FAILED" -ForegroundColor Red
        $out | ForEach-Object { Write-Host $_ }
        exit 2
    }
    Write-Host "build ok" -ForegroundColor Cyan
}

if (-not (Test-Path $dll)) {
    Write-Host "assembly not found: $dll" -ForegroundColor Red
    exit 2
}

try {
    [void][Reflection.Assembly]::LoadFrom($dll)
    $lines = [SelfCheck.Harness]::Run()
} catch {
    Write-Host ("RUN FAILED -> " + $_.Exception.Message) -ForegroundColor Red
    exit 2
}

foreach ($line in $lines) {
    if ($line -match '\[FAIL\]')      { Write-Host $line -ForegroundColor Red }
    elseif ($line -match '\[ OK \]')  { Write-Host $line -ForegroundColor DarkGray }
    else                              { Write-Host $line }
}

$failed = @($lines | Where-Object { $_ -match '\[FAIL\]' }).Count
if ($failed -gt 0) { exit 1 }
exit 0
