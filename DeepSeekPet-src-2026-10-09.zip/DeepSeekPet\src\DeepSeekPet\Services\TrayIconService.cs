using System.Globalization;
using System.Windows;
using DeepSeekPet.Diagnostics;
using DeepSeekPet.Models;

// 本文件是整个工程里唯一重度接触 WinForms 的地方，所以逐类型起别名，
// 避免与 System.Windows.* 撞名（Application / MessageBox / MenuItem / Timer / Screen 等）。
using System.Windows.Forms;
using ContextMenuStrip = System.Windows.Forms.ContextMenuStrip;
using NotifyIcon = System.Windows.Forms.NotifyIcon;
using ToolStripMenuItem = System.Windows.Forms.ToolStripMenuItem;
using ToolStripSeparator = System.Windows.Forms.ToolStripSeparator;
using DrawingIcon = System.Drawing.Icon;

namespace DeepSeekPet.Services;

/// <summary>
/// 托盘图标 + 右键菜单 + 低余额提醒。
///
/// Windows 11 的现实：气泡通知（ShowBalloonTip）已降级 —— 瞬态、不进操作中心、
/// timeout 参数被忽略、可能被专注助手/勿扰静默吞掉，甚至调用返回成功但什么都不显示。
/// 因此气泡只当<b>尽力而为</b>，真正保证能传达信息的是三条：
///   ① 托盘 tooltip 文本（每轮刷新都写）
///   ② 低余额时图标换成警示图标
///   ③ 桌宠本身换成 exhausted 表情
/// </summary>
internal sealed class TrayIconService : IDisposable
{
    // 菜单内容不在这里定义 —— 由 PetMenu.Build 统一构建后传进来，
    // 使托盘菜单与宠物右键菜单共用同一份文案与回调。
    private readonly IReadOnlyList<PetMenuEntry> _menuEntries;

    private NotifyIcon? _icon;
    private ContextMenuStrip? _menu;
    private DrawingIcon? _normalIcon;
    private bool _low;

    public TrayIconService(IReadOnlyList<PetMenuEntry> menuEntries)
    {
        _menuEntries = menuEntries;
    }

    public bool BalloonEnabled { get; set; } = true;

    public void Initialize()
    {
        _normalIcon = LoadTrayIcon();

        _menu = new ContextMenuStrip();
        foreach (var entry in _menuEntries)
        {
            if (entry.IsSeparator) _menu.Items.Add(new ToolStripSeparator());
            else _menu.Items.Add(MakeItem(entry.Text, entry.Invoke));
        }

        _icon = new NotifyIcon
        {
            Icon = _normalIcon,
            ContextMenuStrip = _menu,
            Text = "DeepSeek 桌宠",
            Visible = true,
        };
        _icon.DoubleClick += (_, _) => ToggleFirstEntry();

        Log.Info("托盘图标已初始化");
    }

    /// <summary>双击托盘图标 = 第一项（显示 / 隐藏桌宠）。</summary>
    private void ToggleFirstEntry()
    {
        var first = _menuEntries.FirstOrDefault(e => !e.IsSeparator);
        if (first is null) return;
        try { first.Invoke(); }
        catch (Exception ex) { Log.Error("托盘双击处理失败", ex); }
    }

    private static ToolStripMenuItem MakeItem(string text, Action onClick)
    {
        var item = new ToolStripMenuItem(text);
        item.Click += (_, _) =>
        {
            try { onClick(); }
            catch (Exception ex) { Log.Error($"托盘菜单「{text}」执行失败", ex); }
        };
        return item;
    }

    /// <summary>
    /// 从嵌入资源加载 .ico。NotifyIcon.Icon 必须是真正的 System.Drawing.Icon，
    /// 直接塞 PNG 是不行的（这是常见误解）。
    /// </summary>
    private static DrawingIcon? LoadTrayIcon()
    {
        try
        {
            var uri = new Uri("pack://application:,,,/Assets/tray.ico", UriKind.Absolute);
            var res = Application.GetResourceStream(uri);
            if (res?.Stream is { } s)
            {
                using (s) return new DrawingIcon(s);
            }
        }
        catch (Exception ex)
        {
            Log.Error("加载 tray.ico 失败，退回系统默认图标", ex);
        }
        return System.Drawing.SystemIcons.Application;
    }

    /// <summary>每次刷新后调用：更新 tooltip 文本，并按低余额状态切换图标。</summary>
    public void UpdateBalance(BalanceSnapshot snap, bool low)
    {
        if (_icon is null) return;

        _low = low;

        string text = snap.HasError
            ? $"DeepSeek 桌宠 · {BalanceErrorMessages.ToUserString(snap.Error)}"
            : $"DeepSeek 余额 {snap.Symbol}{snap.Total.ToString("0.00", CultureInfo.InvariantCulture)} · {snap.FetchedAt.LocalDateTime:HH:mm}";

        // NotifyIcon.Text 在 .NET 6+ 上限约 127 字符，超长会抛 ArgumentOutOfRangeException
        _icon.Text = Truncate(text, 120);

        try
        {
            // 低余额时换一个视觉上截然不同的图标 —— 这是不依赖气泡的保证通道之一
            _icon.Icon = low ? System.Drawing.SystemIcons.Warning : _normalIcon;
        }
        catch (Exception ex) { Log.Warn($"切换托盘图标失败: {ex.Message}"); }
    }

    public void ShowLowBalanceBalloon(decimal total, string symbol, decimal threshold)
    {
        if (_icon is null || !BalloonEnabled) return;

        // Visible 必须先为 true，否则气泡被静默丢弃（本方法在 Initialize 之后调用，已满足）
        if (!_icon.Visible)
        {
            Log.Warn("托盘图标不可见，跳过气泡");
            return;
        }

        try
        {
            _icon.ShowBalloonTip(
                timeout: 5000,
                tipTitle: "DeepSeek 余额不足",
                tipText: $"当前余额 {symbol}{total.ToString("0.00", CultureInfo.InvariantCulture)}，" +
                         $"已低于 {symbol}{threshold.ToString("0.00", CultureInfo.InvariantCulture)}，请及时充值。",
                tipIcon: ToolTipIcon.Warning);
            Log.Info("已尝试弹出低余额气泡（Win11 上可能被系统抑制）");
        }
        catch (Exception ex) { Log.Warn($"弹气泡失败: {ex.Message}"); }
    }

    public void ShowInfo(string title, string message)
    {
        try { _icon?.ShowBalloonTip(4000, title, Truncate(message, 200), ToolTipIcon.Info); }
        catch { /* 尽力而为 */ }
    }

    private static string Truncate(string s, int max) =>
        s.Length <= max ? s : s[..max];

    public void Dispose()
    {
        // 顺序很重要：先 Visible=false 再 Dispose，否则托盘里会残留一个幽灵图标
        try
        {
            if (_icon is not null)
            {
                _icon.Visible = false;
                _icon.Dispose();
                _icon = null;
            }
        }
        catch (Exception ex) { Log.Warn($"释放托盘图标失败: {ex.Message}"); }

        _menu?.Dispose();
        _menu = null;
        _normalIcon?.Dispose();
        _normalIcon = null;

        Log.Info("托盘已释放");
    }
}
