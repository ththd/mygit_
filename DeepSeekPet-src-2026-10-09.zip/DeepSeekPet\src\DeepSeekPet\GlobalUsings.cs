// UseWindowsForms=true 会让 System.Windows.* 和 System.Windows.Forms.* 的若干类型名二义。
// csproj 里已经 <Using Remove="System.Windows.Forms" /> 挡掉了隐式 using，
// 这里再把容易撞的几个名称明确钉死到 WPF 一侧。
// 真正需要 WinForms 的文件（TrayIconService / MonitorHelper）自己局部 using 并起别名。

global using Application = System.Windows.Application;
global using MessageBox = System.Windows.MessageBox;
global using Clipboard = System.Windows.Clipboard;

global using System.IO;
global using System.Net.Http;
global using System.Text.Json;
global using System.Text.Json.Serialization;
