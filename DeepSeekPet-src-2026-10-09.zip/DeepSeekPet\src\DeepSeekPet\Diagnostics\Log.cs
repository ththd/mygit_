using System.Text;

namespace DeepSeekPet.Diagnostics;

/// <summary>
/// 零依赖的滚动文件日志。写到 %LOCALAPPDATA%\DeepSeekPet\log.txt，超过阈值截断一次。
/// 桌宠是常驻无界面的程序，出错时没有控制台可看，只能靠这个。
/// </summary>
internal static class Log
{
    private static readonly object Gate = new();
    private static readonly string Dir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DeepSeekPet");
    private static readonly string FilePath = Path.Combine(Dir, "log.txt");
    private const long MaxBytes = 512 * 1024;

    public static void Info(string msg) => Write("INFO ", msg);
    public static void Warn(string msg) => Write("WARN ", msg);

    public static void Error(string msg, Exception? ex = null) =>
        Write("ERROR", ex is null ? msg : $"{msg} :: {ex.GetType().Name}: {ex.Message}");

    private static void Write(string level, string msg)
    {
        var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level}] {msg}{Environment.NewLine}";
        System.Diagnostics.Debug.Write(line);
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(Dir);
                RollIfNeeded();
                File.AppendAllText(FilePath, line, Encoding.UTF8);
            }
        }
        catch
        {
            // 日志绝不能把程序搞崩
        }
    }

    private static void RollIfNeeded()
    {
        try
        {
            var fi = new FileInfo(FilePath);
            if (fi.Exists && fi.Length > MaxBytes)
            {
                var bak = FilePath + ".1";
                if (File.Exists(bak)) File.Delete(bak);
                File.Move(FilePath, bak);
            }
        }
        catch { /* 滚动失败就算了 */ }
    }
}
