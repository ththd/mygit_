using DeepSeekPet.Models;

namespace DeepSeekPet.Services;

/// <summary>相邻两次余额快照比较出的情绪倾向。</summary>
internal enum BalanceMood
{
    /// <summary>没变化、不该表演、或刚表演过被节流。</summary>
    None,
    Up,
    Down,
}

/// <summary>
/// 余额涨跌判定。<b>纯逻辑、零 WPF 依赖</b>，时间由调用方注入，因此可脱离 GUI 断言。
///
/// 几个必须显式处理、否则一定会出错的情形：
///
///  · <b>首次观测必须返回 None。</b> 程序刚启动，还没有「上一次」可比 ——
///    若把第一份快照当成「从 0 涨到 110」，每次开机宠物都会莫名其妙欢呼一次。
///  · <b>错误快照一律 None，且不得污染基准值。</b> 失败时 <c>Total</c> 是 0，
///    若把它记进 <c>_last</c>，那么网络恢复后的第一份正常快照就会读成「暴涨」。
///  · <b>跨阈值的那一次返回 None。</b> 跌破/回升阈值各有专门的事件
///    （<c>LowBalanceDetected</c> / <c>BalanceRecovered</c>），那里有更贴合的表情。
///    这里再报一次，就会变成「先哭一下、再跳一下」的重复表演。
///  · <b>余额本来就更常往下走。</b> 每调用一次 API 都在花钱，所以下跌是常态、
///    上涨（充值/退款）才是罕见事件 —— 因此 Down 的节流窗口远长于 Up，
///    且调用方对 Down 基本不做动效（见 <c>App.OnBalanceUpdated</c>）。
/// </summary>
internal sealed class BalanceMoodTracker
{
    /// <summary>小于一分钱的变化不算数，避免浮点噪声触发假反应。</summary>
    private const decimal Epsilon = 0.01m;

    private static readonly TimeSpan UpCooldown = TimeSpan.FromSeconds(20);
    private static readonly TimeSpan DownCooldown = TimeSpan.FromSeconds(90);

    private decimal? _last;
    private DateTime _lastUpAt = DateTime.MinValue;
    private DateTime _lastDownAt = DateTime.MinValue;

    public BalanceMood Observe(BalanceSnapshot snap, decimal threshold, DateTime now)
    {
        // 失败快照的 Total=0 不是「余额跌到 0」，绝不能记进基准
        if (snap.HasError) return BalanceMood.None;

        var total = snap.Total;
        var previous = _last;
        _last = total;

        if (previous is not { } prev) return BalanceMood.None;   // 首次观测

        // 跨阈值交给专门的事件去表演，这里保持沉默
        if (prev < threshold != total < threshold) return BalanceMood.None;

        var delta = total - prev;
        if (Math.Abs(delta) < Epsilon) return BalanceMood.None;

        if (delta > 0)
        {
            if (now - _lastUpAt < UpCooldown) return BalanceMood.None;
            _lastUpAt = now;
            return BalanceMood.Up;
        }

        if (now - _lastDownAt < DownCooldown) return BalanceMood.None;
        _lastDownAt = now;
        return BalanceMood.Down;
    }
}
