using System.Globalization;
using System.Windows;
using DeepSeekPet.Diagnostics;
using DeepSeekPet.Services;

namespace DeepSeekPet.Views;

internal partial class SettingsWindow : Window
{
    private readonly ApiKeyStore _keyStore;
    private readonly AppSettings _settings;

    /// <summary>用户点了保存且校验通过。</summary>
    public bool Saved { get; private set; }

    /// <summary>Key 被改动过（保存后需要立刻刷新一次）。</summary>
    public bool KeyChanged { get; private set; }

    public SettingsWindow(ApiKeyStore keyStore, AppSettings settings)
    {
        InitializeComponent();

        _keyStore = keyStore;
        _settings = settings;

        var hasKey = keyStore.HasKey();
        KeyHint.Text = hasKey
            ? "已保存密钥。留空表示不修改（密钥以 DPAPI 加密存在本机，不会上传）。"
            : "尚未设置。到 platform.deepseek.com 生成 sk- 开头的密钥后粘贴到这里。";
        ClearKeyButton.IsEnabled = hasKey;

        ThresholdBox.Text = _settings.Balance.LowBalanceThreshold.ToString("0.00", CultureInfo.InvariantCulture);
        IntervalBox.Text = _settings.Balance.RefreshSeconds.ToString(CultureInfo.InvariantCulture);
        BalloonCheck.IsChecked = _settings.Tray.ShowBalloonOnLowBalance;

        AnimEnabledCheck.IsChecked = _settings.Animation.Enabled;
        ReactionsCheck.IsChecked = _settings.Animation.Reactions;
        BalanceMoodCheck.IsChecked = _settings.Animation.BalanceMood;
        BlinkCheck.IsChecked = _settings.Animation.Blink;
        UpdateAnimSubEnabled();
    }

    private void OnAnimEnabledToggled(object sender, RoutedEventArgs e) => UpdateAnimSubEnabled();

    /// <summary>
    /// 总开关关掉时把细项变灰。注意只改 <c>IsEnabled</c>、不动 <c>IsChecked</c> ——
    /// 否则用户临时关一下总开关再打开，三个细项的选择全被重置了。
    /// </summary>
    private void UpdateAnimSubEnabled()
    {
        var on = AnimEnabledCheck.IsChecked == true;
        ReactionsCheck.IsEnabled = on;
        BalanceMoodCheck.IsEnabled = on;
        BlinkCheck.IsEnabled = on;
    }

    private void OnSave(object sender, RoutedEventArgs e)
    {
        ErrorText.Visibility = Visibility.Collapsed;

        // 阈值：宽松解析 —— 用户在本机文化下可能打成 "10,5"。InvariantCulture 兜底。
        if (!TryParseDecimal(ThresholdBox.Text, out var threshold) || threshold < 0)
        {
            Fail("低余额阈值需要是一个不小于 0 的数字。");
            return;
        }

        if (!int.TryParse(IntervalBox.Text.Trim(), NumberStyles.Integer,
                          CultureInfo.InvariantCulture, out var interval))
        {
            Fail("刷新间隔需要是整数秒。");
            return;
        }

        // 夹取而不是报错：小于 15s 会撞限流，大于 600s 就失去“盯着余额”的意义
        var clamped = Math.Clamp(interval, 15, 600);
        if (clamped != interval)
            Log.Info($"刷新间隔 {interval}s 超出范围，已夹取为 {clamped}s");

        var typedKey = KeyBox.Password.Trim();
        if (typedKey.Length > 0)
        {
            if (!typedKey.StartsWith("sk-", StringComparison.OrdinalIgnoreCase))
            {
                Fail("API Key 看起来不对：DeepSeek 的密钥以 sk- 开头。");
                return;
            }
            _keyStore.Save(typedKey);
            KeyChanged = true;
        }

        _settings.Balance.LowBalanceThreshold = threshold;
        _settings.Balance.RefreshSeconds = clamped;
        _settings.Tray.ShowBalloonOnLowBalance = BalloonCheck.IsChecked == true;

        // 总开关关着时，细项保持它们在界面上的值 —— 灰掉只是不生效，不抹掉用户的选择
        _settings.Animation.Enabled = AnimEnabledCheck.IsChecked == true;
        _settings.Animation.Reactions = ReactionsCheck.IsChecked == true;
        _settings.Animation.BalanceMood = BalanceMoodCheck.IsChecked == true;
        _settings.Animation.Blink = BlinkCheck.IsChecked == true;

        Saved = true;
        DialogResult = true;
    }

    private void OnClearKey(object sender, RoutedEventArgs e)
    {
        var r = MessageBox.Show(
            this,
            "确定要清除本机保存的 API Key 吗？\n清除后桌宠将显示「未设置 API Key」，直到你重新填入。",
            "清除 API Key",
            MessageBoxButton.OKCancel,
            MessageBoxImage.Warning);

        if (r != MessageBoxResult.OK) return;

        _keyStore.Clear();
        KeyChanged = true;
        KeyHint.Text = "已清除。填入新的密钥后保存即可。";
        ClearKeyButton.IsEnabled = false;
        KeyBox.Clear();
    }

    private void OnCancel(object sender, RoutedEventArgs e)
    {
        Saved = false;
        DialogResult = false;
    }

    private static bool TryParseDecimal(string raw, out decimal value)
    {
        raw = raw.Trim();
        // 先按本机文化解析（用户就是照自己习惯打的），再退回 InvariantCulture
        return decimal.TryParse(raw, NumberStyles.Number, CultureInfo.CurrentCulture, out value)
            || decimal.TryParse(raw, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
    }

    private void Fail(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}
