// 让发布源码能在 net48 下原样编译所必需的两个桩。
// 它们不改变任何被链接源码的行为 —— 只是补上 .NET Framework 缺失的编译器/框架类型。

namespace System.Runtime.CompilerServices
{
    /// <summary>
    /// <c>record</c> 与 <c>init</c> 访问器要求这个类型存在，它从 .NET 5 起才进框架。
    /// 这是官方文档给出的标准垫片（shim），没有任何实现。
    /// </summary>
    internal static class IsExternalInit { }
}

namespace System.Text.Json.Serialization
{
    /// <summary>
    /// net48 没有 System.Text.Json。但 <c>BalanceModels.cs</c> 里只把这个特性当作
    /// <b>标注</b>使用（`[property: JsonPropertyName("...")]`），自检并不做序列化，
    /// 所以一个不存储任何东西的空实现就足以让真实模型文件原样编译通过 ——
    /// 从而 <c>BalanceSnapshot</c> / <c>BalanceParser</c> 用的都是发布版本的真身，
    /// 而不是另写一份复制品。
    /// </summary>
    [AttributeUsage(
        AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter,
        AllowMultiple = false)]
    internal sealed class JsonPropertyNameAttribute : Attribute
    {
        public JsonPropertyNameAttribute(string name) => Name = name;

        public string Name { get; }
    }
}
