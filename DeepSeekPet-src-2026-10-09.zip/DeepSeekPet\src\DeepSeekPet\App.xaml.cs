using System.Windows;
using System.Windows.Threading;
using DeepSeekPet.Animation;
using DeepSeekPet.Diagnostics;
using DeepSeekPet.Models;
using DeepSeekPet.Services;
using DeepSeekPet.ViewModels;
using DeepSeekPet.Views;

namespace DeepSeekPet;

/// <summary>
/// 组装根。没有 DI 容器 —— 依赖一共就这几个，构造函数手写比引框架更好读。
/// 生命周期：ShutdownMode=OnExplicitShutdown，窗口关闭不等于程序退出，
/// 桌宠必须能在没有窗口的情况下靠托盘活着。
/// </summary>
public partial class App : Application
{
    private SingleInstance? _instance;
    private SettingsStore? _settingsStore;
    private ApiKeyStore? _keyStore;
    private AppSettings? _settings;
    private SpriteSet? _sprites;
    private PetViewModel? _vm;
    private MainWindow? _window;
    private TrayIconService? _tray;
    private BalanceService? _balance;
    private BalanceMoodTracker? _mood;

    private bool _exiting;
    private int _unhandledCount;

    /// <summary>为 true 时主窗口才允许真正关闭（见 MainWindow.OnClosing）。</summary>
    internal static bool IsShuttingDown { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        try
        {
            Log.Info("──────── DeepSeek 桌宠启动 ────────");

            // 单实例：第二个实例不干活，只给已有实例递个信号然后自己退场。
            // 默认是「把它们宠物唤出来」，带 --exit 则是「让它退出」。
            _instance = new SingleInstance();
            if (!_instance.IsFirst)
            {
                var wantExit = e.Args.Any(a => a.Equals("--exit", StringComparison.OrdinalIgnoreCase));
                Log.Info(wantExit ? "已有实例在运行，通知它退出" : "已有实例在运行，通知它显示后退出");
                _instance.SignalExisting(wantExit);
                Shutdown(0);
                return;
            }

            DispatcherUnhandledException += OnDispatcherUnhandledException;

            _settingsStore = new SettingsStore();
            _settings = _settingsStore.Load();
            _keyStore = new ApiKeyStore();

            _sprites = SpriteSet.Load();
            _vm = new PetViewModel();

            _window = new MainWindow(_vm, _settings, _settingsStore, _sprites);
            _window.PetClicked += (_, _) => _ = _balance?.RefreshNowAsync();
            _window.Show();

            // 菜单只定义一次，托盘与宠物右键共用同一个数组 ——
            // 两边的文案/顺序/回调在结构上不可能漂移。
            var menu = PetMenu.Build(
                togglePet: TogglePet,
                refreshNow: () => _ = _balance?.RefreshNowAsync(),
                openSettings: OpenSettings,
                exit: ExitApp);

            _window.SetPetMenu(menu);

            _tray = new TrayIconService(menu)
            {
                BalloonEnabled = _settings.Tray.ShowBalloonOnLowBalance,
            };
            _tray.Initialize();

            _instance.ListenForSignals(
                onShow: () => Dispatcher.BeginInvoke(new Action(ShowPet)),
                onExit: () => Dispatcher.BeginInvoke(new Action(ExitApp)));

            _mood = new BalanceMoodTracker();
            _balance = new BalanceService(CreateClient(), _keyStore, _settings);
            _balance.Updated += OnBalanceUpdated;
            _balance.LowBalanceDetected += OnLowBalance;
            _balance.BalanceRecovered += OnBalanceRecovered;   // 事件一直在，此前从没人订阅
            _balance.Start();

            // 首跑没密钥 = 一只不显示任何数字的宠物，看起来像坏了。直接把设置窗推给用户。
            if (!_keyStore.HasKey())
            {
                Log.Info("未检测到 API Key，首跑引导打开设置窗口");
                Dispatcher.BeginInvoke(new Action(OpenSettings), DispatcherPriority.ApplicationIdle);
            }
        }
        catch (Exception ex)
        {
            Log.Error("启动失败", ex);
            MessageBox.Show($"启动失败：\n\n{ex.Message}\n\n详情见 %LOCALAPPDATA%\\DeepSeekPet\\log.txt",
                            "DeepSeek 桌宠", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    /// <summary>
    /// 真客户端 / 假客户端二选一。假客户端由环境变量驱动，让「无 key、无网络」
    /// 也能完整验证余额显示、低余额提醒、错误态三条链路。
    /// </summary>
    private static IBalanceClient CreateClient()
    {
        var fakeBalance = Environment.GetEnvironmentVariable("DEEPSEEPET_FAKE_BALANCE");
        var fakeSeq = Environment.GetEnvironmentVariable("DEEPSEEPET_FAKE_BALANCE_SEQ");
        var fakeError = Environment.GetEnvironmentVariable("DEEPSEEPET_FAKE_ERROR");

        if (!string.IsNullOrWhiteSpace(fakeBalance)
            || !string.IsNullOrWhiteSpace(fakeSeq)
            || !string.IsNullOrWhiteSpace(fakeError))
        {
            Log.Warn($"使用 FakeBalanceClient（FAKE_BALANCE='{fakeBalance}' "
                     + $"FAKE_BALANCE_SEQ='{fakeSeq}' FAKE_ERROR='{fakeError}'）");
            return new FakeBalanceClient();
        }

        return new DeepSeekBalanceClient();
    }

    private void OnBalanceUpdated(object? sender, BalanceSnapshot snap)
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (_window is null || _settings is null || _tray is null) return;

            // 「未设置 Key」不是故障，不该让宠物摆出凶脸吓用户
            var isRealError = snap.HasError && snap.Error != BalanceErrorKind.NoApiKey;
            var low = !snap.HasError && snap.Total < _settings.Balance.LowBalanceThreshold;

            _window.ApplyBalance(snap, low);
            _tray.UpdateBalance(snap, low);

            _window.Animator.SetState(
                low ? PetState.LowBalance :
                isRealError ? PetState.Error :
                PetState.Normal);

            // 涨跌情绪。注意跨阈值那一次 Observe 会返回 None ——
            // 那种场合由 LowBalanceDetected / BalanceRecovered 用自己的表情负责，
            // 否则会出现「刚哭完又弹一下」的重复表演。
            switch (_mood?.Observe(snap, _settings.Balance.LowBalanceThreshold, DateTime.UtcNow))
            {
                case BalanceMood.Up:
                    _window.Animator.React(PetReaction.Hop);
                    break;

                case BalanceMood.Down:
                    // 刻意不做动效：素材下边缘余量为 0，任何向下位移都会切掉角色；
                    // 而哭脸要留给「跌破阈值那一刻」，日常消耗掉的几毛钱配不上它。
                    Log.Info("余额下降（仅记录，不做动效）");
                    break;
            }
        }));
    }

    private void OnBalanceRecovered(object? sender, EventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            // 这是原本就存在、却一直没人订阅的事件。回升时基线已被上面那轮
            // 刷新改回 Normal，所以 Settle 不会被门控挡掉。
            _window?.Animator.React(PetReaction.Settle);
        }));
    }

    private void OnLowBalance(object? sender, LowBalanceEventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            // 只在「跌破阈值」那一刻走到这里（BalanceService 做跳变检测），
            // 所以这里不需要再去重，否则会 60 秒弹一次。
            _tray?.ShowLowBalanceBalloon(e.Total, e.Symbol, e.Threshold);

            if (_window is { IsVisible: true })
                _tray?.ShowInfo("DeepSeek 余额不足",
                    $"当前余额 {e.Symbol}{e.Total:0.00}，已低于 {e.Symbol}{e.Threshold:0.00}。");

            // 哭一下。素材是「流着眼泪」的，正合这一幕，所以只在跌破阈值时用。
            // 此时基线已由上面那轮刷新设为 LowBalance，门控放行。
            _window?.Animator.React(PetReaction.Cry);
        }));
    }

    private void TogglePet()
    {
        if (_window is null) return;
        if (_window.IsVisible) HidePet();
        else ShowPet();
    }

    private void HidePet()
    {
        // 隐藏时停掉浮动 timer：不可见的窗口没有任何重绘理由，
        // 而分层窗口的重绘是本项目唯一的持续 CPU 开销。
        _window?.PauseAnimation();
        _window?.Hide();
        Log.Info("桌宠已隐藏");
    }

    private void ShowPet()
    {
        if (_window is null) return;
        if (!_window.IsVisible) _window.Show();
        _window.Topmost = true;   // 重新显示时确保回到最前
        _window.Activate();
        _window.ResumeAnimation();
        Log.Info("桌宠已显示");
    }

    private void OpenSettings()
    {
        if (_keyStore is null || _settings is null || _settingsStore is null) return;

        // 弹模态框期间冻住动画：模态消息循环会让 DispatcherTimer 继续跑，
        // 但用户在填表，背后一直动的东西很分心。
        _window?.PauseAnimation();
        try
        {
            var dlg = new SettingsWindow(_keyStore, _settings) { Owner = _window };
            var ok = dlg.ShowDialog() == true;

            if (ok)
            {
                _settingsStore.Save(_settings);
                if (_tray is not null)
                    _tray.BalloonEnabled = _settings.Tray.ShowBalloonOnLowBalance;

                // 动效开关热应用：用户点了「关掉动效」就该立刻停，而不是等下次重启
                _window?.ApplyAnimationSettings();

                Log.Info($"设置已保存：阈值 {_settings.Balance.LowBalanceThreshold:0.00}，"
                         + $"间隔 {_settings.Balance.RefreshSeconds}s，KeyChanged={dlg.KeyChanged}");

                // 刷新间隔在 BalanceService 里是每轮读取的，改完下一轮自然生效，
                // 但用户期望「点了保存就看到变化」，所以立刻补一次。
                _ = _balance?.RefreshNowAsync();
            }
        }
        catch (Exception ex) { Log.Error("打开设置窗口失败", ex); }
        finally
        {
            if (_window is { IsVisible: true }) _window.ResumeAnimation();
        }
    }

    private void ExitApp()
    {
        if (_exiting) return;
        _exiting = true;
        IsShuttingDown = true;
        Log.Info("用户请求退出");

        try
        {
            // 先停轮询：避免退出过程中还有 HTTP 在飞、回调打到已释放的 UI 上
            try { _balance?.StopAsync().Wait(TimeSpan.FromSeconds(2)); }
            catch (Exception ex) { Log.Warn($"停止轮询超时: {ex.Message}"); }
        }
        finally
        {
            // 托盘必须先于窗口清理，且顺序是 Visible=false → Dispose，
            // 否则托盘区会残留一个悬停才消失的幽灵图标。
            try { _tray?.Dispose(); } catch (Exception ex) { Log.Warn($"释放托盘失败: {ex.Message}"); }
            try { _window?.Close(); } catch (Exception ex) { Log.Warn($"关闭窗口失败: {ex.Message}"); }

            Shutdown(0);
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        // ExitApp 之外的退出路径（比如致命异常）也要保证托盘被清掉
        try { _tray?.Dispose(); } catch { }
        try { _balance?.Dispose(); } catch { }
        try { _instance?.Dispose(); } catch { }

        Log.Info("──────── 已退出 ────────");
        base.OnExit(e);
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Log.Error("未处理异常", e.Exception);
        _unhandledCount++;

        // 单个异常不该让桌宠直接消失，但反复异常时硬扛着也没意义
        if (_unhandledCount >= 3)
        {
            Log.Error($"未处理异常累计 {_unhandledCount} 次，放弃并退出");
            e.Handled = true;
            ExitApp();
            return;
        }

        e.Handled = true;
        try
        {
            _tray?.ShowInfo("DeepSeek 桌宠遇到问题",
                $"{e.Exception.GetType().Name}: {e.Exception.Message}（详情见 log.txt）");
        }
        catch { /* 连提示都失败就只留日志 */ }
    }
}
