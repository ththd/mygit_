using System.Windows;

namespace DeepSeekPet.Services;

/// <summary>一个菜单项。<c>IsSeparator</c> 为 true 时 <c>Text</c> 与 <c>Invoke</c> 被忽略。</summary>
internal sealed record PetMenuEntry(string Text, Action Invoke, bool IsSeparator = false);

/// <summary>
/// 托盘菜单与宠物右键菜单的<b>唯一</b>定义处：文案、顺序、分隔线、回调全在这里。
///
/// 两处各自渲染成各自的框架控件（托盘是 WinForms <c>ToolStripMenuItem</c>，
/// 宠物是 WPF <c>MenuItem</c>），但都读同一个数组，所以「改了一处忘了另一处」
/// 这种漂移在结构上不可能发生 —— 不是靠纪律维持。
/// </summary>
internal static class PetMenu
{
    public static IReadOnlyList<PetMenuEntry> Build(
        Action togglePet, Action refreshNow, Action openSettings, Action exit) => new[]
    {
        new PetMenuEntry("显示 / 隐藏桌宠", togglePet),
        new PetMenuEntry("立即刷新余额", refreshNow),
        new PetMenuEntry("设置…", openSettings),
        new PetMenuEntry("关于", ShowAbout),
        new PetMenuEntry("", () => { }, IsSeparator: true),
        new PetMenuEntry("退出", exit),
    };

    /// <summary>从 TrayIconService 挪到这里，让两个菜单共用同一份署名信息。</summary>
    internal static void ShowAbout()
    {
        MessageBox.Show(
            "DeepSeek 桌宠 v1.1\n\n" +
            "角色素材来自以下 MIT 许可项目，版权归原作者所有：\n" +
            "  · ManjuSage/deepseek-usage-pet  (c) 2026 MeteorNOX\n" +
            "    （表情立绘源自 MeteorNOX/DeepSeek-Balance-Whale-Widget 的 For-WinDesktop 分支）\n" +
            "详见 THIRD-PARTY-NOTICES.md。\n\n" +
            "API Key 仅以 DPAPI 加密保存在本机，不会上传。",
            "关于 DeepSeek 桌宠",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }
}
