using System.Security.Cryptography;
using System.Text;
using DeepSeekPet.Diagnostics;

namespace DeepSeekPet.Services;

/// <summary>
/// API Key 的本地存储：DPAPI（CurrentUser 作用域）加密后写 %LOCALAPPDATA%\DeepSeekPet\apikey.bin。
///
/// 安全等级说明（务必如实告知用户）：这是<b>混淆级</b>，不是真正的安全。
/// 以同一用户身份运行的任何进程都能调用 Unprotect 解出来。它只防住
/// “别人拷走文件”“另一个 Windows 账户”“备份泄露”这几类场景。
/// 客户端持有第三方密钥本质上就无法做到真正保密 —— 除非走服务端代理。
///
/// 放 LOCALAPPDATA 而非 Roaming：DPAPI 密文绑定「本机 + 本用户」，
/// 放进会同步的 Roaming 会导致换台机器就解不开。
/// </summary>
internal sealed class ApiKeyStore
{
    // 固定熵值：让密文只对本应用有意义（防止别处解密同一份数据）
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("DeepSeekPet.v1.api-key");

    private static readonly string Dir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DeepSeekPet");

    private static readonly string KeyPath = Path.Combine(Dir, "apikey.bin");

    public bool HasKey()
    {
        var k = Load();
        return !string.IsNullOrWhiteSpace(k);
    }

    public string? Load()
    {
        try
        {
            if (!File.Exists(KeyPath)) return null;
            var blob = File.ReadAllBytes(KeyPath);
            if (blob.Length == 0) return null;
            var plain = ProtectedData.Unprotect(blob, Entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plain);
        }
        catch (Exception ex)
        {
            // 换机器 / 换用户 / 密文损坏都会走到这里，属于可预期情况
            Log.Warn($"API Key 解密失败（将视为未设置）: {ex.GetType().Name}: {ex.Message}");
            return null;
        }
    }

    public void Save(string key)
    {
        var plain = Encoding.UTF8.GetBytes(key);
        var blob = ProtectedData.Protect(plain, Entropy, DataProtectionScope.CurrentUser);
        WriteAtomic(blob);
        Log.Info("API Key 已保存（DPAPI 加密）");
    }

    public void Clear()
    {
        try
        {
            if (File.Exists(KeyPath)) File.Delete(KeyPath);
            Log.Info("API Key 已清除");
        }
        catch (Exception ex) { Log.Error("清除 API Key 失败", ex); }
    }

    /// <summary>临时文件 + 原子替换，避免写一半崩溃导致密文损坏。</summary>
    private static void WriteAtomic(byte[] blob)
    {
        Directory.CreateDirectory(Dir);
        var tmp = KeyPath + ".tmp";
        File.WriteAllBytes(tmp, blob);

        if (File.Exists(KeyPath))
        {
            // File.Replace 是原子的；目标存在时用它
            File.Replace(tmp, KeyPath, destinationBackupFileName: null);
        }
        else
        {
            File.Move(tmp, KeyPath);
        }
    }
}
