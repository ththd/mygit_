using DeepSeekPet.Diagnostics;
using DeepSeekPet.Models;

namespace DeepSeekPet.Services;

/// <summary>
/// 由环境变量驱动的假客户端。用途：无真 Key、无网络时跑通全部功能。
///
///   DEEPSEEPET_FAKE_BALANCE  = "110.00"  成功返回该余额
///   DEEPSEEPET_FAKE_BALANCE_SEQ = "110,109.5,111.2"  按序取值（取完循环），
///                                优先级高于 FAKE_BALANCE，用于端到端验证「涨 / 跌 / 节流」
///   DEEPSEEPET_FAKE_ERROR    = 401|402|429|500|timeout|decode|network   合成对应失败
///   DEEPSEEPET_FAKE_DELAY_MS = "800"     模拟延迟，用于验证「请求不重叠」
///
/// 每次调用都重新读环境变量，所以改完环境变量不必重新编译。
/// </summary>
internal sealed class FakeBalanceClient : IBalanceClient
{
    private static int _sequenceIndex;

    public bool RequiresApiKey => false;

    public async Task<BalanceSnapshot> GetAsync(string apiKey, CancellationToken ct)
    {
        var delayMs = ReadInt("DEEPSEEPET_FAKE_DELAY_MS", 0);
        if (delayMs > 0)
            await Task.Delay(delayMs, ct);

        var err = Environment.GetEnvironmentVariable("DEEPSEEPET_FAKE_ERROR");
        if (!string.IsNullOrWhiteSpace(err))
        {
            var kind = err.Trim().ToLowerInvariant() switch
            {
                "401" => BalanceErrorKind.Unauthorized,
                "402" => BalanceErrorKind.InsufficientBalance,
                "429" => BalanceErrorKind.RateLimited,
                "500" or "503" => BalanceErrorKind.ServerError,
                "timeout" => BalanceErrorKind.Timeout,
                "network" => BalanceErrorKind.NetworkError,
                "decode" => BalanceErrorKind.DecodeError,
                "nokey" => BalanceErrorKind.NoApiKey,
                _ => BalanceErrorKind.NetworkError,
            };
            Log.Info($"[Fake] 合成失败: {kind}");
            return BalanceSnapshot.Failure(kind, "fake");
        }

        var raw = NextRawBalance();

        // 特意走真实的解析路径 —— 这样连 "abc" 这种畸形值也能顺带被测到，
        // 证实 decimal 解析确实有护栏（会落到 DecodeError 而不是抛异常/算错）。
        var resp = new BalanceResponse(true, new List<BalanceEntry>
        {
            new("CNY", raw, "10.00", "100.00"),
        });

        var snap = BalanceParser.ToSnapshot(resp);
        Log.Info($"[Fake] 返回余额 total='{raw}' -> {(snap.HasError ? snap.Error.ToString() : snap.Total.ToString())}");
        return snap;
    }

    /// <summary>
    /// 序列模式下按调用次序取下一个值，取完<b>循环</b>而不是停在最后一个 ——
    /// 停住的话，长时间观察「涨→跌→被节流」就只看得到一轮，循环才能反复看。
    /// </summary>
    private static string NextRawBalance()
    {
        var seq = Environment.GetEnvironmentVariable("DEEPSEEPET_FAKE_BALANCE_SEQ");
        if (!string.IsNullOrWhiteSpace(seq))
        {
            var parts = seq.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (parts.Length > 0)
            {
                var n = Interlocked.Increment(ref _sequenceIndex) - 1;
                var value = parts[(int)(n % parts.Length)];
                Log.Info($"[Fake] 序列第 {n + 1} 次 -> '{value}'（共 {parts.Length} 个，循环取值）");
                return value;
            }
        }

        return Environment.GetEnvironmentVariable("DEEPSEEPET_FAKE_BALANCE") ?? "110.00";
    }

    private static int ReadInt(string name, int fallback) =>
        int.TryParse(Environment.GetEnvironmentVariable(name), out var v) ? v : fallback;
}
