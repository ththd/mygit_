namespace DeepSeekPet.Animation;

/// <summary>
/// 持久基线状态 —— 由余额刷新驱动，长时间不变。
/// 与短时的 <see cref="PetReaction"/> 相对：那是「表情上的惊鸿一瞥」，
/// 而这是「这只宠物现在处于什么状况」。
///
/// 单独成文件是为了让状态机那一层能<b>不带任何 WPF 依赖</b>地被编译与执行
/// （见 <c>DeepSeekPet-tools\selfcheck</c>），因此这里的成员顺序同样有意义：
/// 状态机对 <see cref="LowBalance"/> 和 <see cref="Error"/> 的门控是按名字写的。
/// </summary>
internal enum PetState
{
    Normal,
    LowBalance,
    Error,
}
