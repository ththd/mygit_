# Resample the 610x610 source sprites down to 360x360.
# 360 is chosen deliberately: the pet box is 180 DIP, and this machine runs at
# 200% scaling (192 DPI), so 180 DIP == 360 physical px. Shipping 360px assets
# makes the on-screen mapping exactly 1:1 -> sharp, and no per-frame resampling.
# (A 180px asset was being upscaled 2x; a 610px asset would be downsampled every
# frame, costing CPU for no visible gain at this DPI.)
# ASCII-only on purpose: PS 5.1 reads .ps1 with the ANSI codepage when no BOM.
#
# The map is deliberately explicit rather than a directory glob: the source repo
# also ships DSniang02.png / DSH2.png / rua.gif which must NOT end up in the app.
# Sources absent from -SrcDir are skipped, so this is safe to re-run with a
# partial download set.
param(
  [string]$SrcDir = "C:\Users\lenovo\DeepSeekPet-tools\_raw2",
  [string]$DstDir = "C:\Users\lenovo\DeepSeekPet\src\DeepSeekPet\Assets\Sprites",
  [int]$Size = 360
)

Add-Type -AssemblyName System.Drawing

# source filename -> path relative to the app's Assets/Sprites folder
$map = [ordered]@{
  "base.png"             = "base.png"
  "exhausted.png"        = "expressions\exhausted.png"
  "angry.png"            = "expressions\angry.png"
  "shy.png"              = "expressions\shy.png"
  "press.png"            = "expressions\press.png"
  "disappointed.png"     = "expressions\disappointed.png"
  "blink_half_open.png"  = "blink\blink_half_open.png"
  "blink_half.png"       = "blink\blink_half.png"
  "blink_closed.png"     = "blink\blink_closed.png"
}

foreach ($rel in $map.Values) {
  $parent = Split-Path (Join-Path $DstDir $rel) -Parent
  if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Force $parent | Out-Null }
}

foreach ($name in $map.Keys) {
  $src = Join-Path $SrcDir $name
  $dst = Join-Path $DstDir $map[$name]
  if (-not (Test-Path $src)) { Write-Output "SKIP (missing) $src"; continue }

  $img = [System.Drawing.Image]::FromFile($src)
  $out = New-Object System.Drawing.Bitmap($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $gr = [System.Drawing.Graphics]::FromImage($out)
  $gr.CompositingMode    = [System.Drawing.Drawing2D.CompositingMode]::SourceCopy  # keep alpha, do not blend onto black
  $gr.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
  $gr.InterpolationMode  = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $gr.PixelOffsetMode    = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $gr.SmoothingMode      = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $gr.DrawImage($img, (New-Object System.Drawing.Rectangle(0, 0, $Size, $Size)))
  $gr.Dispose()
  $img.Dispose()

  $out.Save($dst, [System.Drawing.Imaging.ImageFormat]::Png)
  $out.Dispose()

  $chk = [System.Drawing.Image]::FromFile($dst)
  Write-Output ("{0,-22} -> {1,-32} {2}x{3}  {4} bytes" -f $name, $map[$name], $chk.Width, $chk.Height, (Get-Item $dst).Length)
  $chk.Dispose()
}
