using System.Net;
using DeepSeekPet.Diagnostics;
using DeepSeekPet.Models;

namespace DeepSeekPet.Services;

/// <summary>
/// 真实客户端：GET https://api.deepseek.com/user/balance
///
/// 设计原则：<b>预期内的失败一律不抛异常</b>，而是返回一个带 Error 的快照，
/// 这样 UI / 托盘 / 动画总是有东西可渲染，不需要到处 try/catch。
/// </summary>
internal sealed class DeepSeekBalanceClient : IBalanceClient
{
    private const string BalanceUrl = "https://api.deepseek.com/user/balance";

    // 静态复用：HttpClient 每次 new 会导致 socket 耗尽
    private static readonly HttpClient Http = CreateClient();

    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        PropertyNameCaseInsensitive = true,
    };

    private static HttpClient CreateClient()
    {
        var handler = new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(2),
            ConnectTimeout = TimeSpan.FromSeconds(10),
        };
        var c = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(15) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("DeepSeekPet/1.0");
        return c;
    }

    public async Task<BalanceSnapshot> GetAsync(string apiKey, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
            return BalanceSnapshot.Failure(BalanceErrorKind.NoApiKey);

        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, BalanceUrl);
            req.Headers.TryAddWithoutValidation("Authorization", $"Bearer {apiKey}");
            req.Headers.TryAddWithoutValidation("Accept", "application/json");

            using var resp = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);

            if (resp.StatusCode != HttpStatusCode.OK)
            {
                var body = await SafeReadAsync(resp, ct);
                var kind = MapStatus((int)resp.StatusCode);
                Log.Warn($"余额接口返回 {(int)resp.StatusCode} -> {kind}; body={Truncate(body, 200)}");
                return BalanceSnapshot.Failure(kind, $"HTTP {(int)resp.StatusCode}");
            }

            var json = await resp.Content.ReadAsStringAsync(ct);
            BalanceResponse? parsed;
            try
            {
                parsed = JsonSerializer.Deserialize<BalanceResponse>(json, JsonOpts);
            }
            catch (JsonException ex)
            {
                Log.Warn($"余额响应 JSON 解析失败: {ex.Message}");
                return BalanceSnapshot.Failure(BalanceErrorKind.DecodeError, "JSON 解析失败");
            }

            if (parsed is null)
                return BalanceSnapshot.Failure(BalanceErrorKind.DecodeError, "响应为空");

            return BalanceParser.ToSnapshot(parsed);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // 调用方主动取消（退出/停止轮询），不是错误
            throw;
        }
        catch (OperationCanceledException)
        {
            // HttpClient.Timeout 触发（内部用 CancellationToken 实现），ct 没被取消
            Log.Warn("余额请求超时");
            return BalanceSnapshot.Failure(BalanceErrorKind.Timeout);
        }
        catch (HttpRequestException ex)
        {
            Log.Warn($"余额请求网络错误: {ex.Message}");
            return BalanceSnapshot.Failure(BalanceErrorKind.NetworkError, ex.Message);
        }
        catch (Exception ex)
        {
            Log.Error("余额请求未预期异常", ex);
            return BalanceSnapshot.Failure(BalanceErrorKind.NetworkError, ex.Message);
        }
    }

    private static BalanceErrorKind MapStatus(int status) => status switch
    {
        400 => BalanceErrorKind.InvalidFormat,
        401 => BalanceErrorKind.Unauthorized,
        402 => BalanceErrorKind.InsufficientBalance,
        422 => BalanceErrorKind.InvalidParams,
        429 => BalanceErrorKind.RateLimited,
        >= 500 => BalanceErrorKind.ServerError,
        _ => BalanceErrorKind.NetworkError,
    };

    private static async Task<string> SafeReadAsync(HttpResponseMessage resp, CancellationToken ct)
    {
        try { return await resp.Content.ReadAsStringAsync(ct); }
        catch { return ""; }
    }

    private static string Truncate(string s, int max) =>
        string.IsNullOrEmpty(s) ? "" : (s.Length <= max ? s : s[..max] + "…");
}
