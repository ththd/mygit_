using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using DeepSeekPet.Diagnostics;
using DeepSeekPet.Services;

namespace DeepSeekPet.Animation;

/// <summary>
/// 待机动效 + 表情切换。
///
/// 动效取舍（有实测依据）：
///  · <b>只做垂直浮动，不做缩放/旋转。</b> 素材的不透明内容齐着画布右边和下边
///    （bbox 右/下都到 359，最后一行列有数百个实心像素）—— 角色是胸像，头发与身体
///    本就被画布裁断。所以向右平移、向下平移、顺时针旋转、整体拉伸一律会切掉角色。
///    唯一安全的方向是向上。
///  · 浮动用 DispatcherTimer 按 ~15fps 手工推进，而<b>不用 Storyboard</b>：
///    Storyboard 跑满 60fps，而 AllowsTransparency 的分层窗口每帧都要
///    GPU→系统内存往返（这是本项目最大的 CPU 风险）。15fps 对这种几像素的
///    缓动位移已经足够顺滑，重绘量却降为 1/4。
///  · 位置值变化小于半像素时直接跳过，进一步减少无效重绘。
///  · 反应位移<b>与浮动做加权混合</b>而不是直接相加：直接相加会让上限变成
///    「浮动 3 + 弹跳 4.5 = 7.5 DIP」，恰好吃掉所有顶部余量；混合则严格封顶在 4.5 DIP。
///    混合权重带 15% 的进出斜坡，所以交接处不会出现位置跳变。
/// </summary>
internal sealed class SpriteAnimator : IDisposable
{
    private const double AmplitudePx = 3.0;   // 浮动幅度，别调大：静态插画的“呼吸感”全靠克制
    private const double PeriodSeconds = 3.2;
    private const int FrameIntervalMs = 66;   // ≈15fps

    /// <summary>睡着时呼吸变慢变深。4.5 DIP 仍低于所有素材中最小的顶部余量（7.5 DIP）。</summary>
    private const double SleepAmplitudePx = 4.5;
    private const double SleepPeriodScale = 2.0;

    /// <summary>弹跳峰值。4.5 DIP 是照着「最小顶部余量 7.5 DIP」留足安全边际定的。</summary>
    private const double HopPeakPx = 4.5;
    private const double SettlePeakPx = 2.0;

    private const double IdleSleepAfterSeconds = 180;
    private const double SleepBlendSeconds = 1.5;   // 入睡/惊醒的过渡时长

    private const int BlinkFrameMs = 35;            // 眨眼总共 5 步 ≈ 175ms
    private const int BlinkSteps = 5;

    private readonly Image _baseLayer;
    private readonly Image _fadeLayer;
    private readonly TranslateTransform _bob;
    private readonly SpriteSet _sprites;
    private readonly PetStateMachine _machine = new();

    private readonly DispatcherTimer _bobTimer;
    private readonly DispatcherTimer _blinkTimer;

    private AnimationSettings _settings = new();

    private DateTime _lastTick = DateTime.UtcNow;
    private DateTime _lastActivity = DateTime.UtcNow;
    private DateTime _nextBlinkAt = DateTime.UtcNow;

    private double _angle;          // 累积角相位：改周期时值仍然连续，不会跳
    private double _sleepBlend;     // 0=清醒 1=熟睡，缓慢过渡

    private int _blinkStep = -1;    // -1=没在眨眼；0..4 是 半开→半闭→全闭→半闭→半开
    private bool _active;           // 期望在跑（Pause 后为 false）

    private ImageSource? _currentImage;   // 期望显示的目标图，用于去重
    private int _fadeGen;                 // 淡入代次：作废被新淡入取代的 Completed 回调
    private double _lastAppliedY = double.NaN;

    public SpriteAnimator(SpriteSet sprites, Image baseLayer, Image fadeLayer, TranslateTransform bob)
    {
        _sprites = sprites;
        _baseLayer = baseLayer;
        _fadeLayer = fadeLayer;
        _bob = bob;

        _baseLayer.Source = sprites.Base;
        _currentImage = sprites.Base;
        _fadeLayer.Opacity = 0;

        _bobTimer = new DispatcherTimer(DispatcherPriority.Render)
        {
            Interval = TimeSpan.FromMilliseconds(FrameIntervalMs),
        };
        _bobTimer.Tick += OnBobTick;

        _blinkTimer = new DispatcherTimer(DispatcherPriority.Render)
        {
            Interval = TimeSpan.FromMilliseconds(BlinkFrameMs),
        };
        _blinkTimer.Tick += OnBlinkTick;
    }

    public void Start()
    {
        _lastTick = DateTime.UtcNow;
        _nextBlinkAt = DateTime.UtcNow.AddSeconds(2);
        Resume();
    }

    public void Pause()
    {
        _active = false;
        _bobTimer.Stop();
        _blinkTimer.Stop();
    }

    public void Resume()
    {
        _active = true;
        _lastTick = DateTime.UtcNow;   // 否则恢复后的第一帧会拿到一个巨大的 dt
        if (_settings.Enabled && !_bobTimer.IsEnabled) _bobTimer.Start();
    }

    /// <summary>
    /// 热应用动效设置。总开关关掉时<b>不是</b>停掉一切了事：
    /// 余额基线（正常 / 疲惫 / 报错）的换图必须保留 —— 那是功能，不是动效。
    /// </summary>
    public void ApplySettings(AnimationSettings settings)
    {
        _settings = settings;
        _machine.ClearAll();
        _blinkStep = -1;
        _blinkTimer.Stop();

        if (!settings.Enabled)
        {
            _sleepBlend = 0;
            _angle = 0;
            _lastAppliedY = double.NaN;   // 强制重新提交，否则「归零」会被去重守卫吞掉
            ApplyY(0);
        }
        else if (_active && !_bobTimer.IsEnabled)
        {
            _lastTick = DateTime.UtcNow;
            _bobTimer.Start();
        }

        RefreshExpression(DateTime.UtcNow);
    }

    /// <summary>
    /// 切基线状态。<b>签名与语义与原版一致</b>（同状态去重），只是转发给状态机，
    /// 因此 <c>App.OnBalanceUpdated</c> 那处调用点一个字都不用改。
    /// 总开关关闭时这个方法依然生效 —— 低余额该换的疲惫脸照样换。
    /// </summary>
    public void SetState(PetState state)
    {
        if (!_machine.SetBaseline(state)) return;
        Log.Info($"桌宠状态 -> {state}");
        RefreshExpression(DateTime.UtcNow);
    }

    /// <summary>
    /// 请求一个短时反应。哪个开关管哪一类反应在这里<b>统一</b>决定，
    /// 免得调用方各自记住「Cry 归余额开关、其余归互动开关」这种易漂移的规则。
    /// </summary>
    public void React(PetReaction reaction)
    {
        _lastActivity = DateTime.UtcNow;

        var allowed = _settings.Enabled && reaction switch
        {
            PetReaction.Cry or PetReaction.Settle => _settings.BalanceMood,
            _ => _settings.Reactions,
        };
        if (!allowed) return;

        var now = DateTime.UtcNow;
        if (!_machine.TryReact(reaction, now)) return;   // 被基线门控拒绝
        RefreshExpression(now);
    }

    public void BeginPress()
    {
        _lastActivity = DateTime.UtcNow;
        if (!_settings.Enabled || !_settings.Reactions) return;

        _machine.BeginPress();
        RefreshExpression(DateTime.UtcNow);
    }

    public void EndPress()
    {
        _lastActivity = DateTime.UtcNow;
        _machine.EndPress();
        RefreshExpression(DateTime.UtcNow);
    }

    /// <summary>
    /// 「鼠标在宠物附近动过」。与 React 分开是因为悬停反应有停留时长和限频，
    /// 被节流掉的那些悬停<b>仍然应该算作互动</b> —— 否则宠物会在用户明明在戳它的时候睡着。
    /// </summary>
    public void NotifyActivity()
    {
        _lastActivity = DateTime.UtcNow;
        if (!_machine.IsSleeping) return;

        _machine.SetSleeping(false);
        RefreshExpression(DateTime.UtcNow);
    }

    private void OnBobTick(object? sender, EventArgs e)
    {
        var now = DateTime.UtcNow;
        var dt = Math.Min((now - _lastTick).TotalSeconds, 0.25);
        _lastTick = now;

        if (dt <= 0) return;

        if (_settings.Enabled)
        {
            // 长时间没被搭理 -> 打瞌睡。按住时绝不入睡（正被拎着呢）。
            if (!_machine.IsSleeping && !_machine.IsPressed
                && (now - _lastActivity).TotalSeconds >= IdleSleepAfterSeconds)
            {
                _machine.SetSleeping(true);
            }

            _machine.ClearExpired(now);
            ScheduleBlink(now);
        }

        ApplyY(ComputeY(now, dt));
        RefreshExpression(now);
    }

    /// <summary>
    /// 半像素量化后提交位移：值没实质变化就不写，省掉一次分层窗口重绘。
    ///
    /// 判定<b>必须是「小于则提前返回」</b>，不能写成「大于等于才提交」——
    /// <c>_lastAppliedY</c> 的哨兵值是 <c>NaN</c>，而 NaN 的任何比较都是 false，
    /// 改成后者会让守卫在重置后<b>永远</b>不通过，宠物直接不动了。
    /// </summary>
    private void ApplyY(double y)
    {
        var quantized = Math.Round(y * 2, MidpointRounding.AwayFromZero) / 2.0;
        if (Math.Abs(quantized - _lastAppliedY) < 0.001) return;

        _lastAppliedY = quantized;
        _bob.Y = quantized;
    }

    /// <summary>
    /// 浮动 + 反应位移的加权混合。睡着时靠 <see cref="_sleepBlend"/> 把幅度和周期
    /// 连续地推过去 —— 直接改周期会让 cos 的自变量跳变，看起来是「瞬间弹了一下」。
    /// </summary>
    private double ComputeY(DateTime now, double dt)
    {
        if (!_settings.Enabled) return 0;

        var dir = _machine.IsSleeping ? 1.0 : -1.0;
        _sleepBlend = Math.Clamp(_sleepBlend + dir * dt / SleepBlendSeconds, 0.0, 1.0);

        var period = PeriodSeconds * (1 + (SleepPeriodScale - 1) * _sleepBlend);
        var amplitude = AmplitudePx + (SleepAmplitudePx - AmplitudePx) * _sleepBlend;

        _angle += 2 * Math.PI / period * dt;
        if (_angle > 2 * Math.PI) _angle -= 2 * Math.PI;   // 防长时间运行后精度流失

        var bobY = -amplitude * (1 - Math.Cos(_angle)) / 2.0;

        if (_machine.ActiveReaction(now) is not { } r) return bobY;
        if (CurveOf(r.Kind) is not { } curve) return bobY;   // Shy / Cry 只换图，不位移

        var w = Envelope(r.Progress);
        return (1 - w) * bobY + w * curve(r.Progress);
    }

    /// <summary>两端各 15% 的进出斜坡，保证与浮动交接时位置连续。</summary>
    private static double Envelope(double u) =>
        Math.Min(1.0, Math.Min(u, 1 - u) / 0.15);

    private static Func<double, double>? CurveOf(PetReaction r) => r switch
    {
        // 向上弹跳：sin 在半程处到达峰值，两端为 0，天然就是「起跳—回落」
        PetReaction.Hop => u => -HopPeakPx * Math.Sin(Math.PI * u),
        PetReaction.Settle => u => -SettlePeakPx * Math.Sin(Math.PI * u),
        _ => null,
    };

    // ── 眨眼 ────────────────────────────────────────────────────────────────

    /// <summary>眨眼只在「解析出来正好是 base 姿势」时才安排 —— 见 PetStateMachine.CanBlink。</summary>
    private void ScheduleBlink(DateTime now)
    {
        if (!_settings.Blink || _blinkStep >= 0) return;
        if (_sprites.BlinkFrames.Count != 3) return;
        if (now < _nextBlinkAt) return;

        // 不到点也要重排，否则门控期间会每 66ms 试一次
        _nextBlinkAt = now.AddSeconds(3 + Random.Shared.NextDouble() * 4);
        if (!_machine.CanBlink(now)) return;

        _blinkStep = 0;
        ShowBlinkFrame(0);
        _blinkTimer.Start();
    }

    private void OnBlinkTick(object? sender, EventArgs e)
    {
        var now = DateTime.UtcNow;

        // 眨眼途中被按住 / 睡着了 / 状态变了，立刻中止（否则会停在半闭眼睛上）
        if (!_machine.CanBlink(now)) { EndBlink(); return; }

        _blinkStep++;
        if (_blinkStep >= BlinkSteps) { EndBlink(); return; }

        ShowBlinkFrame(_blinkStep);
    }

    private void EndBlink()
    {
        _blinkTimer.Stop();
        _blinkStep = -1;
        RefreshExpression(DateTime.UtcNow);
    }

    /// <summary>眨眼帧 0→1→2→1→0，即 半开→半闭→全闭→半闭→半开。</summary>
    private static int FrameIndexOf(int step) => step <= 2 ? step : 4 - step;

    /// <summary>
    /// 显式映射到表情枚举，<b>不靠枚举成员的声明顺序做加法</b> ——
    /// 那种写法在有人往枚举中间插一个成员时会静默错位。
    /// </summary>
    private static PetExpression BlinkExpressionOf(int step) => FrameIndexOf(step) switch
    {
        0 => PetExpression.BlinkHalfOpen,
        1 => PetExpression.BlinkHalf,
        _ => PetExpression.BlinkClosed,
    };

    /// <summary>
    /// 眨眼是<b>硬切</b>而不是交叉淡入：它本来就是一段 175ms 的快速动画，
    /// 每帧再套 250ms 淡入只会糊成一团灰。素材与 base 轮廓对齐（差异 1.1–1.2%），
    /// 硬切正是它该有的样子。
    /// </summary>
    private void ShowBlinkFrame(int step)
    {
        var img = _sprites.ImageOf(BlinkExpressionOf(step));
        if (img is null) { EndBlink(); return; }

        _fadeGen++;              // 作废正在飞的淡入，它会盖掉这帧硬切
        _baseLayer.Source = img;
        _currentImage = img;
        _fadeLayer.BeginAnimation(UIElement.OpacityProperty, null);
        _fadeLayer.Opacity = 0;
    }

    // ── 表情 ────────────────────────────────────────────────────────────────

    /// <summary>
    /// <c>_baseLayer.Source</c> 的<b>唯一写者</b>（除硬切的眨眼帧外）。
    /// 单一写者是这个类里最容易被破坏的约束：多一处直接赋值，就会出现
    /// 「淡入动画的 Completed 回调把更晚的意图覆盖回去」这类只偶发、难复现的错图。
    /// </summary>
    private void RefreshExpression(DateTime now)
    {
        var expr = _machine.Resolve(now);

        if (_blinkStep >= 0 && _machine.CanBlink(now))
            expr = BlinkExpressionOf(_blinkStep);

        // 素材缺失时退回基线图，而不是留一块空白
        var img = _sprites.ImageOf(expr) ?? _sprites.Base;
        if (ReferenceEquals(img, _currentImage)) return;

        CrossFadeTo(img);
    }

    /// <summary>用 250ms 交叉淡入而非硬切 —— 不同素材之间色差明显，
    /// 硬切会像“换了一只”，淡入读起来才是“宠物在反应”。</summary>
    private void CrossFadeTo(ImageSource target)
    {
        _currentImage = target;

        // 代次自增：即便下面提前返回，也必须作废在飞的旧 Completed
        var gen = ++_fadeGen;

        if (ReferenceEquals(_baseLayer.Source, target))
        {
            _fadeLayer.BeginAnimation(UIElement.OpacityProperty, null);
            _fadeLayer.Opacity = 0;
            return;
        }

        // 淡入层承载新图，动画结束后把它“落”到基础层，再复位
        _fadeLayer.Source = target;
        _fadeLayer.BeginAnimation(UIElement.OpacityProperty, null);
        _fadeLayer.Opacity = 0;

        var fade = new DoubleAnimation
        {
            From = 0,
            To = 1,
            Duration = TimeSpan.FromMilliseconds(250),
            EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut },
        };

        fade.Completed += (_, _) =>
        {
            // 期间又开始了新的淡入 -> 这个回调已经过时，直接丢弃
            if (gen != _fadeGen) return;
            _baseLayer.Source = target;
            _fadeLayer.BeginAnimation(UIElement.OpacityProperty, null);
            _fadeLayer.Opacity = 0;
        };

        _fadeLayer.BeginAnimation(UIElement.OpacityProperty, fade);
    }

    public void Dispose()
    {
        _bobTimer.Stop();
        _bobTimer.Tick -= OnBobTick;
        _blinkTimer.Stop();
        _blinkTimer.Tick -= OnBlinkTick;
    }
}
