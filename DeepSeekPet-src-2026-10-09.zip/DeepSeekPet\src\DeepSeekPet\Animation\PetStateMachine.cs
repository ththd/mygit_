namespace DeepSeekPet.Animation;

/// <summary>短时反应（有超时，结束就回到基线）。</summary>
internal enum PetReaction
{
    /// <summary>鼠标悬停 —— 爱心害羞。</summary>
    Shy,
    /// <summary>单击 / 余额上涨 —— 纯位移弹跳，不换图。</summary>
    Hop,
    /// <summary>余额跌破阈值那一刻 —— 哭一下。</summary>
    Cry,
    /// <summary>余额回升到阈值以上 —— 轻轻起伏后归位。</summary>
    Settle,
}

/// <summary>可以真正显示出来的表情图。与素材文件一一对应。</summary>
internal enum PetExpression
{
    Base,
    Exhausted,
    Angry,
    Shy,
    /// <summary>闭眼平静的脸。既用于「按住被拎起来」，也用于「长时间没理它，睡着了」。</summary>
    Press,
    /// <summary>流着眼泪的哭脸。只在跌破阈值那一刻用。</summary>
    Disappointed,
    BlinkHalfOpen,
    BlinkHalf,
    BlinkClosed,
}

/// <summary>
/// 桌宠的表情决策。<b>纯逻辑：不引用任何 WPF 类型</b>，时间由调用方注入
/// （<c>DateTime now</c>），因此它的行为可以在不启动 GUI 的前提下被断言验证 ——
/// 在一台连程序都跑不起来的机器上，这是唯一能真正验证这段逻辑的手段。
///
/// 优先级是<b>分层 + 门控</b>，不是单一的优先级链：
///
/// <code>
///   ① 按住中 / 睡着了   → Press          最高，但天然短暂或可被打断
///   ② 活动中的短时反应  → 反应表情（若有）
///   ③ 基线              → Base / Exhausted / Angry     持久、权威
///   ④ 眨眼              → 仅在 ③ 恰好是 Base 时才允许  最低，被门控
/// </code>
///
/// 基线之所以用<b>门控</b>而不是抢占来体现权威，是为了避免「余额没涨却高兴地跳」
/// 这种说谎：低余额时允许害羞，但不允许弹跳。
/// </summary>
internal sealed class PetStateMachine
{
    private PetReaction? _reaction;
    private DateTime _reactionStartedAt;

    private bool _pressed;
    private bool _sleeping;

    public PetState Baseline { get; private set; } = PetState.Normal;

    public bool IsPressed => _pressed;

    public bool IsSleeping => _sleeping;

    /// <summary>设置持久基线。返回 true 表示确实变了（供调用方去重）。</summary>
    public bool SetBaseline(PetState state)
    {
        if (Baseline == state) return false;
        Baseline = state;

        // 基线一变，正在表演的反应若在新基线下不被允许就地作废 ——
        // 否则会出现「刚报错却还在弹跳」。
        if (_reaction is { } r && !Allowed(state, r)) _reaction = null;

        return true;
    }

    /// <summary>请求一个短时反应。被基线门控拒绝时返回 false。</summary>
    public bool TryReact(PetReaction reaction, DateTime now)
    {
        if (!Allowed(Baseline, reaction)) return false;

        _sleeping = false;              // 任何反应都把宠物叫醒
        _reaction = reaction;
        _reactionStartedAt = now;
        return true;
    }

    public void BeginPress()
    {
        _sleeping = false;
        _pressed = true;
    }

    public void EndPress() => _pressed = false;

    public void SetSleeping(bool sleeping)
    {
        // 只在正常基线下打瞌睡：疲惫脸和报错脸是「有信息量」的状态，不该被盖掉
        _sleeping = sleeping && Baseline == PetState.Normal;
    }

    /// <summary>由每帧的 tick 调用，回收已到期的反应。</summary>
    public void ClearExpired(DateTime now)
    {
        if (_reaction is { } r && now - _reactionStartedAt >= DurationOf(r)) _reaction = null;
    }

    /// <summary>把一切瞬时状态清空，只剩基线。用于暂停 / 关掉总开关。</summary>
    public void ClearAll()
    {
        _reaction = null;
        _pressed = false;
        _sleeping = false;
    }

    /// <summary>当前该显示哪张图（不含眨眼 —— 眨眼由动画器在帧序列里自己决定）。</summary>
    public PetExpression Resolve(DateTime now)
    {
        if (_pressed) return PetExpression.Press;
        if (_sleeping && Baseline == PetState.Normal) return PetExpression.Press;

        if (ImageOfActive(now) is { } img) return img;

        return Baseline switch
        {
            PetState.LowBalance => PetExpression.Exhausted,
            PetState.Error => PetExpression.Angry,
            _ => PetExpression.Base,
        };
    }

    /// <summary>正在进行的反应及其进度 u∈[0,1]。纯位移的反应（Hop / Settle）也走这里。</summary>
    public (PetReaction Kind, double Progress)? ActiveReaction(DateTime now)
    {
        if (_reaction is not { } r) return null;
        var total = DurationOf(r).TotalMilliseconds;
        var done = (now - _reactionStartedAt).TotalMilliseconds;
        if (done >= total) return null;
        // 用 Min/Max 而不是 Math.Clamp：后者在 .NET Framework 4.8 上不存在，
        // 而这一层要被原样编进 net48 的自检程序集去真跑（见 DeepSeekPet-tools\selfcheck）。
        return (r, Math.Min(1.0, Math.Max(0.0, done / total)));
    }

    /// <summary>
    /// 眨眼只在「解析结果恰好是 Base」时允许。
    /// 眨眼素材是 base 姿势的变体，在 exhausted / angry / 按住 / 睡着时切进去，
    /// 会突然跳回正常姿势的眼睛 —— 视觉上直接穿帮。
    /// </summary>
    public bool CanBlink(DateTime now) =>
        !_pressed && !_sleeping && Resolve(now) == PetExpression.Base;

    private PetExpression? ImageOfActive(DateTime now) => ActiveReaction(now) is { Kind: var k }
        ? ImageOf(k)
        : null;

    /// <summary>反应对应的图；返回 null 表示「只动效、不换图」。</summary>
    public static PetExpression? ImageOf(PetReaction r) => r switch
    {
        PetReaction.Shy => PetExpression.Shy,
        PetReaction.Cry => PetExpression.Disappointed,
        _ => null,
    };

    public static TimeSpan DurationOf(PetReaction r) => r switch
    {
        PetReaction.Shy => TimeSpan.FromMilliseconds(1600),
        PetReaction.Hop => TimeSpan.FromMilliseconds(900),
        PetReaction.Cry => TimeSpan.FromMilliseconds(2500),
        PetReaction.Settle => TimeSpan.FromMilliseconds(1200),
        _ => TimeSpan.Zero,
    };

    /// <summary>
    /// 基线对反应的<b>门控</b>表。低余额时不许高兴地跳（余额没涨，那是假话），
    /// 报错时也不表演心情。
    /// </summary>
    private static bool Allowed(PetState baseline, PetReaction r) => baseline switch
    {
        PetState.Normal => true,
        PetState.LowBalance => r is PetReaction.Shy or PetReaction.Cry or PetReaction.Settle,
        PetState.Error => r is PetReaction.Shy,
        _ => false,
    };
}
