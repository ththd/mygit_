using DeepSeekPet.Diagnostics;
using DeepSeekPet.Models;

namespace DeepSeekPet.Services;

internal sealed class LowBalanceEventArgs : EventArgs
{
    public required decimal Total { get; init; }
    public required string Symbol { get; init; }
    public required decimal Threshold { get; init; }
}

/// <summary>
/// 轮询调度 + 事件中枢。三个职责：
///  1. 按间隔轮询，且<b>保证请求不重叠</b>（手动刷新与定时刷新共用同一把信号量）
///  2. 失败退避（429 直接跳 3 倍间隔，5xx/网络错误指数退避，上限 5 分钟）
///  3. 低余额<b>跳变</b>检测 —— 只在「跌破阈值」那一刻报警，否则会每 60 秒弹一次
/// </summary>
internal sealed class BalanceService : IDisposable
{
    private readonly IBalanceClient _client;
    private readonly ApiKeyStore _keyStore;
    private readonly AppSettings _settings;

    private readonly SemaphoreSlim _gate = new(1, 1);
    private CancellationTokenSource? _cts;
    private Task? _loop;

    private bool _wasBelowThreshold;
    private int _consecutiveFailures;
    private int _totalRefreshes;
    private int _manualInFlight;
    private DateTime _lastManualAt = DateTime.MinValue;
    private TimeSpan? _nextDelayOverride;

    /// <summary>两次手动刷新的最小间隔。连点宠物不该变成连打 API。</summary>
    private static readonly TimeSpan MinManualInterval = TimeSpan.FromSeconds(3);

    public event EventHandler<BalanceSnapshot>? Updated;
    public event EventHandler<LowBalanceEventArgs>? LowBalanceDetected;
    public event EventHandler? BalanceRecovered;

    public BalanceSnapshot? Current { get; private set; }

    public bool IsRunning => _loop is { IsCompleted: false };

    public BalanceService(IBalanceClient client, ApiKeyStore keyStore, AppSettings settings)
    {
        _client = client;
        _keyStore = keyStore;
        _settings = settings;
    }

    public void Start()
    {
        if (IsRunning) return;
        _cts = new CancellationTokenSource();
        _loop = Task.Run(() => LoopAsync(_cts.Token));
        Log.Info($"余额轮询已启动，间隔 {_settings.Balance.RefreshSeconds}s");
    }

    public async Task StopAsync()
    {
        var cts = _cts;
        var loop = _loop;
        if (cts is null) return;

        try { cts.Cancel(); } catch { }
        if (loop is not null)
        {
            try { await Task.WhenAny(loop, Task.Delay(TimeSpan.FromSeconds(3))); }
            catch { }
        }
        cts.Dispose();
        _cts = null;
        _loop = null;
        Log.Info("余额轮询已停止");
    }

    /// <summary>
    /// 手动立即刷新（托盘菜单 / 点击宠物 / 设置保存后）。
    ///
    /// <b>合并，不排队。</b> 起初这里只是转手交给信号量，结果连点宠物会排出一串
    /// 真实请求：实测 17 秒内点了 26 下就产生 26 次调用。真实网络下每次 ~300ms，
    /// 连点 20 下就是 20 个串行请求 —— 等着撞 429。
    /// 所以：已有手动刷新在飞 → 丢弃；距上次手动不足 MinManualInterval → 丢弃。
    /// 定时循环不受影响，它本来就有固定节奏。
    /// </summary>
    public Task RefreshNowAsync()
    {
        var ct = _cts?.Token ?? CancellationToken.None;

        // 0 → 1 成功表示当前没有手动刷新在飞
        if (Interlocked.CompareExchange(ref _manualInFlight, 1, 0) == 1)
        {
            Log.Info("手动刷新被合并（已有手动刷新进行中）");
            return Task.CompletedTask;
        }

        var sinceLast = DateTime.UtcNow - _lastManualAt;
        if (sinceLast < MinManualInterval)
        {
            Interlocked.Exchange(ref _manualInFlight, 0);
            Log.Info($"手动刷新被节流（距上次仅 {sinceLast.TotalMilliseconds:N0}ms）");
            return Task.CompletedTask;
        }

        _lastManualAt = DateTime.UtcNow;
        return RunManualAsync(ct);
    }

    private async Task RunManualAsync(CancellationToken ct)
    {
        try { await RefreshCoreAsync(ct, isManual: true); }
        finally { Interlocked.Exchange(ref _manualInFlight, 0); }
    }

    private async Task LoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                await RefreshCoreAsync(ct, isManual: false);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) { Log.Error("轮询循环异常", ex); }

            var delay = _nextDelayOverride ?? TimeSpan.FromSeconds(Math.Max(15, _settings.Balance.RefreshSeconds));
            _nextDelayOverride = null;

            try { await Task.Delay(delay, ct); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task RefreshCoreAsync(CancellationToken ct, bool isManual)
    {
        // 防重叠的关键：定时循环与手动刷新都走这道闸
        await _gate.WaitAsync(ct);
        try
        {
            // 记录触发来源：手动刷新若被意外重复触发（比如某个事件处理里
            // 连点了两次），日志里会连续出现多条 manual，据此可立刻定位。
            Log.Info($"开始刷新（{(isManual ? "手动" : "定时")}，累计 {Interlocked.Increment(ref _totalRefreshes)} 次）");

            var key = _keyStore.Load();
            if (string.IsNullOrWhiteSpace(key) && _client.RequiresApiKey)
            {
                Publish(BalanceSnapshot.Failure(BalanceErrorKind.NoApiKey));
                return;
            }

            var snap = await _client.GetAsync(key ?? "", ct);
            Publish(snap);
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex)
        {
            Log.Error("刷新余额失败", ex);
            Publish(BalanceSnapshot.Failure(BalanceErrorKind.NetworkError, ex.Message));
        }
        finally
        {
            _gate.Release();
        }
    }

    private void Publish(BalanceSnapshot snap)
    {
        Current = snap;

        if (!snap.HasError)
        {
            _consecutiveFailures = 0;
            _nextDelayOverride = null;
        }
        else if (snap.Error == BalanceErrorKind.NoApiKey)
        {
            // 「还没配 Key」不是网络/服务端故障，不该累积退避计数：
            // 否则用户挂着不配 Key 一整天，配好之后第一次真失败会直接继承
            // 一个很大的失败次数，指数退避一步顶到上限（5 分钟），
            // 表现为「刚填完 Key 却半天不刷新」。
            _consecutiveFailures = 0;
            _nextDelayOverride = null;
        }
        else
        {
            _consecutiveFailures++;
            _nextDelayOverride = ComputeBackoff(snap.Error, _consecutiveFailures);
            if (_nextDelayOverride is { } d)
                Log.Warn($"失败退避: 下次延迟 {d.TotalSeconds:N0}s（连续失败 {_consecutiveFailures}）");
        }

        Updated?.Invoke(this, snap);

        // 低余额跳变检测：只在跨越阈值的那一刻触发，避免每轮都弹
        var symbol = snap.Symbol;
        var threshold = _settings.Balance.LowBalanceThreshold;
        var isBelow = !snap.HasError && snap.Total < threshold;

        if (isBelow && !_wasBelowThreshold)
        {
            _wasBelowThreshold = true;
            LowBalanceDetected?.Invoke(this, new LowBalanceEventArgs
            {
                Total = snap.Total,
                Symbol = symbol,
                Threshold = threshold,
            });
        }
        else if (!isBelow && _wasBelowThreshold)
        {
            _wasBelowThreshold = false;
            BalanceRecovered?.Invoke(this, EventArgs.Empty);
        }
    }

    private TimeSpan ComputeBackoff(BalanceErrorKind kind, int failures)
    {
        var baseInterval = TimeSpan.FromSeconds(Math.Max(15, _settings.Balance.RefreshSeconds));
        return kind switch
        {
            // 限流：直接拉到 3 倍，别再猛打
            BalanceErrorKind.RateLimited => TimeSpan.FromTicks(baseInterval.Ticks * 3),
            BalanceErrorKind.ServerError or BalanceErrorKind.NetworkError or BalanceErrorKind.Timeout =>
                // 指数退避，上限 5 分钟
                TimeSpan.FromSeconds(Math.Min(
                    baseInterval.TotalSeconds * Math.Pow(2, Math.Min(failures, 5)), 300)),
            // 密钥/参数类错误重试没意义，按正常间隔来（用户改完 key 自然就好了）
            _ => baseInterval,
        };
    }

    public void Dispose() => _gate.Dispose();
}
