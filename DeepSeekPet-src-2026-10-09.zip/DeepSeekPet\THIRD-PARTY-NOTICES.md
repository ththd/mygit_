# 第三方素材与许可声明

本项目的**代码**为原创。桌宠角色形象、表情立绘以及由它们派生的托盘图标，
来自下列采用 MIT 许可的开源项目。MIT 许可要求在所有副本或实质性部分中
保留版权声明与许可全文，故全文照录如下。

---

## ManjuSage/deepseek-usage-pet

来源：<https://github.com/ManjuSage/deepseek-usage-pet>

本项目中由其派生的文件：

| 本项目路径 | 派生自 |
|---|---|
| `src/DeepSeekPet/Assets/Sprites/base.png` | `assets/DSniang1.png` |
| `src/DeepSeekPet/Assets/Sprites/expressions/exhausted.png` | `assets/expressions/exhausted.png` |
| `src/DeepSeekPet/Assets/Sprites/expressions/angry.png` | `assets/expressions/angry.png` |
| `src/DeepSeekPet/Assets/Sprites/expressions/shy.png` | `assets/expressions/shy.png` |
| `src/DeepSeekPet/Assets/Sprites/expressions/press.png` | `assets/expressions/press.png` |
| `src/DeepSeekPet/Assets/Sprites/expressions/disappointed.png` | `assets/expressions/disappointed.png` |
| `src/DeepSeekPet/Assets/Sprites/blink/blink_half_open.png` | `assets/blink/blink_half_open.png` |
| `src/DeepSeekPet/Assets/Sprites/blink/blink_half.png` | `assets/blink/blink_half.png` |
| `src/DeepSeekPet/Assets/Sprites/blink/blink_closed.png` | `assets/blink/blink_closed.png` |

**处理方式**：原始文件为 610×610，本项目在构建前离线等比降采样至 360×360
（不裁剪、不变形、不改变配色），以 PNG 形式作为 WPF `Resource` 嵌入程序集。
`Assets/tray.ico` 同样由上述角色形象离线缩放打包而成（16/24/32/48/64/128/256 多尺寸）。
这是唯一的改动 —— 除降采样外，本项目未对素材做任何重绘、调色或合成。

### 上游出处链

上述表情立绘并非 `ManjuSage/deepseek-usage-pet` 原创，该仓库是**取用方**。
经查证，这批素材的**上游原始出处**是：

- **`MeteorNOX/DeepSeek-Balance-Whale-Widget`** 的 `For–WinDesktop` 分支，MIT 许可，
  版权归 **MeteorNOX** —— 即下方许可全文的版权人。
  <https://github.com/MeteorNOX/DeepSeek-Balance-Whale-Widget>

同一名称下另有 `xiaolinnnnnnn/DeepSeek-Balance-Whale-Widget`，那是**另一个仓库**
（无 LICENSE 文件，且含第三方商标资源，见下节），与本项目所用素材无关，切勿混淆。
此处照录 MIT 全文，正是为了覆盖到真正的版权人 MeteorNOX。

```
MIT License

Copyright (c) 2026 MeteorNOX

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 评估过但**未采用**的项目

记录下来，免得日后有人以为漏了署名：

- **`Suiwan/whale-purse`**（MIT, © 2026 Zijian Li）— 仓库中有可用的鲸鱼精灵图，
  但画风与主素材不统一，最终未使用其任何文件。
- **`xiaolinnnnnnn/DeepSeek-Balance-Whale-Widget`** — **无 LICENSE 文件**，
  且内含约 60 个第三方厂商 logo（商标风险），不可用。
- **`Egger0/desk-pet`** — **无 LICENSE 文件**，README 限定「仅供个人学习与娱乐」，
  不构成可再分发的授权，不可用。
- **`VKmich16/VK-1`** — 根 LICENSE **仅覆盖** `大肥鱼桌宠改_D-16BVM/`，
  `dsh-balance-pet-macos/` 与 `output/` 被明确排除（属另一位作者），不可用。

## 商标

「DeepSeek」是杭州深度求索人工智能基础技术研究有限公司的商标。
本项目为个人非商业作品，与 DeepSeek 官方**无任何隶属或背书关系**。
