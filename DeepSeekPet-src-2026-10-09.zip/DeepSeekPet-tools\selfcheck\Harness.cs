using DeepSeekPet.Animation;
using DeepSeekPet.Models;
using DeepSeekPet.Services;

namespace SelfCheck;

/// <summary>
/// 桌宠纯逻辑层的断言集。必须 <c>public</c> —— PowerShell 只能按名字解析公开类型。
///
/// 覆盖三块：表情状态机、余额涨跌情绪、余额响应解析。这三块是「就算程序能跑起来、
/// 也很难用肉眼验证对不对」的部分：门控规则、节流窗口、首次观测、错误快照对基准的
/// 污染 —— 全都是要靠时间和特定输入顺序才会暴露的错误。把它们关在纯逻辑里、
/// 用注入的时间来断言，是唯一可靠的办法。
/// </summary>
public static class Harness
{
    private static readonly List<string> Lines = new();
    private static int _pass;
    private static int _fail;

    private static readonly DateTime T0 = new(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc);

    public static string[] Run()
    {
        Lines.Clear();
        _pass = 0;
        _fail = 0;

        Section("PetStateMachine");
        StateMachine();

        Section("BalanceMoodTracker");
        Mood();

        Section("BalanceParser");
        Parser();

        Lines.Insert(0, _fail == 0
            ? $"===== 全部通过：{_pass} 项 ====="
            : $"===== 失败：{_fail} 项（共 {_pass + _fail} 项）=====");

        return Lines.ToArray();
    }

    // ── 表情状态机 ──────────────────────────────────────────────────────────

    private static void StateMachine()
    {
        var m = new PetStateMachine();
        Check(m.Baseline == PetState.Normal, "初始基线是 Normal");
        Check(m.Resolve(T0) == PetExpression.Base, "初始显示 Base");
        Check(m.CanBlink(T0), "Normal + Base 时允许眨眼");
        Check(!m.SetBaseline(PetState.Normal), "重复设置同一基线返回 false（去重）");
        Check(m.SetBaseline(PetState.LowBalance), "切到 LowBalance 返回 true");
        Check(m.Resolve(T0) == PetExpression.Exhausted, "LowBalance 显示 Exhausted");
        Check(!m.CanBlink(T0), "LowBalance 时不允许眨眼");

        // 门控：低余额时不许高兴地跳，但允许害羞
        Check(!m.TryReact(PetReaction.Hop, T0), "LowBalance 门控掉 Hop");
        Check(m.TryReact(PetReaction.Shy, T0), "LowBalance 允许 Shy");
        Check(m.Resolve(T0) == PetExpression.Shy, "Shy 反应期间显示 shy 图");
        Check(m.TryReact(PetReaction.Settle, T0), "LowBalance 允许 Settle");

        // 到期回收
        var shyDur = PetStateMachine.DurationOf(PetReaction.Shy);
        var mid = m.ActiveReaction(T0 + TimeSpan.FromMilliseconds(shyDur.TotalMilliseconds / 2));
        Check(mid is { } active && active.Progress > 0 && active.Progress < 1, "反应进度落在 0~1 之间");
        Check(m.ActiveReaction(T0 + shyDur + TimeSpan.FromMilliseconds(1)) is null, "到期后 ActiveReaction 为 null");
        Check(m.Resolve(T0 + shyDur + TimeSpan.FromMilliseconds(1)) == PetExpression.Exhausted,
              "反应到期后回到 LowBalance 基线");

        // 切基线会作废「新基线下不被允许」的进行中反应
        var m2 = new PetStateMachine();
        Check(m2.TryReact(PetReaction.Hop, T0), "Normal 允许 Hop");
        m2.SetBaseline(PetState.LowBalance);
        Check(m2.ActiveReaction(T0) is null, "基线切到 LowBalance 时，进行中的 Hop 被作废");

        // Error 门控最严：只放行 Shy
        var m3 = new PetStateMachine();
        m3.SetBaseline(PetState.Error);
        Check(m3.Resolve(T0) == PetExpression.Angry, "Error 显示 Angry");
        Check(!m3.TryReact(PetReaction.Hop, T0), "Error 门控掉 Hop");
        Check(!m3.TryReact(PetReaction.Cry, T0), "Error 门控掉 Cry");
        Check(!m3.TryReact(PetReaction.Settle, T0), "Error 门控掉 Settle");
        Check(m3.TryReact(PetReaction.Shy, T0), "Error 允许 Shy");

        // 按住：压过一切基线
        var m4 = new PetStateMachine();
        m4.SetBaseline(PetState.LowBalance);
        m4.BeginPress();
        Check(m4.Resolve(T0) == PetExpression.Press, "按住时压过基线显示 Press");
        Check(!m4.CanBlink(T0), "按住时不允许眨眼");
        m4.EndPress();
        Check(m4.Resolve(T0) == PetExpression.Exhausted, "松手后回到基线");

        // 睡着：只在 Normal 基线成立
        var m5 = new PetStateMachine();
        m5.SetSleeping(true);
        Check(m5.IsSleeping, "Normal 基线下可以进入睡眠");
        Check(m5.Resolve(T0) == PetExpression.Press, "睡着显示 Press");
        Check(!m5.CanBlink(T0), "睡着时不允许眨眼");
        m5.SetBaseline(PetState.LowBalance);
        Check(m5.Resolve(T0) == PetExpression.Exhausted, "基线变 LowBalance 后不再显示睡脸");

        var m6 = new PetStateMachine();
        m6.SetBaseline(PetState.LowBalance);
        m6.SetSleeping(true);
        Check(!m6.IsSleeping, "非 Normal 基线下不允许进入睡眠");

        var m7 = new PetStateMachine();
        m7.SetSleeping(true);
        m7.TryReact(PetReaction.Hop, T0);
        Check(!m7.IsSleeping, "任何反应都会把宠物叫醒");

        var m8 = new PetStateMachine();
        m8.BeginPress();
        m8.TryReact(PetReaction.Hop, T0);
        m8.ClearAll();
        Check(!m8.IsPressed && m8.Resolve(T0) == PetExpression.Base, "ClearAll 清空全部瞬时状态");

        // 素材映射
        Check(PetStateMachine.ImageOf(PetReaction.Shy) == PetExpression.Shy, "Shy 映射到 shy 图");
        Check(PetStateMachine.ImageOf(PetReaction.Cry) == PetExpression.Disappointed, "Cry 映射到 disappointed 图");
        Check(PetStateMachine.ImageOf(PetReaction.Hop) is null, "Hop 是纯位移，不换图");
        Check(PetStateMachine.ImageOf(PetReaction.Settle) is null, "Settle 是纯位移，不换图");

        foreach (var r in new[] { PetReaction.Shy, PetReaction.Hop, PetReaction.Cry, PetReaction.Settle })
            Check(PetStateMachine.DurationOf(r) > TimeSpan.Zero, $"DurationOf({r}) 大于 0");
    }

    // ── 余额涨跌情绪 ────────────────────────────────────────────────────────

    private static void Mood()
    {
        const decimal threshold = 20m;
        var tr = new BalanceMoodTracker();

        Check(tr.Observe(Ok(110m), threshold, T0) == BalanceMood.None,
              "首次观测返回 None（否则每次开机都会凭空欢呼一次）");

        Check(tr.Observe(Ok(100m), threshold, T0.AddSeconds(60)) == BalanceMood.Down, "110 -> 100 判为 Down");
        Check(tr.Observe(Ok(99.5m), threshold, T0.AddSeconds(70)) == BalanceMood.None,
              "90 秒内的第二次下跌被节流");

        // 错误快照：既不表演，也不得污染基准
        Check(tr.Observe(Fail(), threshold, T0.AddSeconds(80)) == BalanceMood.None, "错误快照返回 None");
        Check(tr.Observe(Ok(99.5m), threshold, T0.AddSeconds(90)) == BalanceMood.None,
              "错误快照没把基准清零（否则 99.5 会被读成暴涨）");

        Check(tr.Observe(Ok(99.505m), threshold, T0.AddSeconds(100)) == BalanceMood.None,
              "不足一分钱的变化不算涨跌");

        // 跨阈值交给专门的事件，情绪层保持沉默
        Check(tr.Observe(Ok(15m), threshold, T0.AddSeconds(120)) == BalanceMood.None,
              "跌破阈值那一次返回 None");
        Check(tr.Observe(Ok(25m), threshold, T0.AddSeconds(200)) == BalanceMood.None,
              "回升过阈值那一次也返回 None");

        Check(tr.Observe(Ok(40m), threshold, T0.AddSeconds(300)) == BalanceMood.Up, "25 -> 40 判为 Up");
        Check(tr.Observe(Ok(50m), threshold, T0.AddSeconds(305)) == BalanceMood.None,
              "20 秒内的第二次上涨被节流");
        Check(tr.Observe(Ok(60m), threshold, T0.AddSeconds(400)) == BalanceMood.Up, "冷却过后再次上涨仍会触发");
    }

    // ── 余额解析 ────────────────────────────────────────────────────────────

    private static void Parser()
    {
        var ok = BalanceParser.ToSnapshot(new BalanceResponse(true, new List<BalanceEntry>
        {
            new("CNY", "110.00", "10.00", "100.00"),
        }));
        Check(!ok.HasError && ok.Total == 110.00m, "正常响应解析出 110.00");
        Check(ok.Symbol == "¥", "CNY 映射到 ¥ 符号");

        var bad = BalanceParser.ToSnapshot(new BalanceResponse(true, new List<BalanceEntry>
        {
            new("CNY", "abc", "10.00", "100.00"),
        }));
        Check(bad.Error == BalanceErrorKind.DecodeError, "畸形金额落到 DecodeError 而不是抛异常");

        var empty = BalanceParser.ToSnapshot(new BalanceResponse(true, new List<BalanceEntry>()));
        Check(empty.Error == BalanceErrorKind.DecodeError, "空 balance_infos 落到 DecodeError");

        var nullInfos = BalanceParser.ToSnapshot(new BalanceResponse(true, null));
        Check(nullInfos.Error == BalanceErrorKind.DecodeError, "null balance_infos 落到 DecodeError");

        var usd = BalanceParser.ToSnapshot(new BalanceResponse(true, new List<BalanceEntry>
        {
            new("USD", "5.00", "0", "5.00"),
            new("CNY", "110.00", "10.00", "100.00"),
        }), preferred: "USD");
        Check(usd.Total == 5.00m && usd.Symbol == "$", "按偏好选中 USD 条目");

        // 偏好币种在响应里不存在时才退回第一项。
        // 注意默认偏好是 CNY，所以这里必须传一个确实不存在的币种才能验到回退分支。
        var fallback = BalanceParser.ToSnapshot(new BalanceResponse(true, new List<BalanceEntry>
        {
            new("EUR", "7.00", "0", "7.00"),
            new("CNY", "110.00", "10.00", "100.00"),
        }), preferred: "JPY");
        Check(fallback.Total == 7.00m, "偏好币种缺失时退回第一项");

        // 有 CNY 时默认就该选 CNY，而不是「碰巧第一项」
        var cnySecond = BalanceParser.ToSnapshot(new BalanceResponse(true, new List<BalanceEntry>
        {
            new("EUR", "7.00", "0", "7.00"),
            new("CNY", "110.00", "10.00", "100.00"),
        }));
        Check(cnySecond.Total == 110.00m, "默认偏好下选中第二项里的 CNY");

        var failure = BalanceSnapshot.Failure(BalanceErrorKind.NoApiKey);
        Check(failure.HasError && failure.Error == BalanceErrorKind.NoApiKey, "Failure() 造出的快照带错误标记");
    }

    // ── 工具 ────────────────────────────────────────────────────────────────

    private static BalanceSnapshot Ok(decimal total) =>
        new(true, "CNY", total, 0m, total, DateTimeOffset.UtcNow, BalanceErrorKind.None, null);

    private static BalanceSnapshot Fail() => BalanceSnapshot.Failure(BalanceErrorKind.NetworkError);

    private static void Section(string name)
    {
        Lines.Add("");
        Lines.Add($"── {name} ──");
    }

    private static void Check(bool ok, string what)
    {
        if (ok)
        {
            _pass++;
            Lines.Add($"  [ OK ] {what}");
        }
        else
        {
            _fail++;
            Lines.Add($"  [FAIL] {what}");
        }
    }
}
