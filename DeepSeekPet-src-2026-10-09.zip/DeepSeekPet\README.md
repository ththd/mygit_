# DeepSeek 鲸鱼娘桌宠

一只常驻桌面的 Q 版 DeepSeek 角色，主要工作是**盯着你的 API 余额**。

透明无边框、置顶、不进任务栏、不出现在 Alt+Tab。可以拖到屏幕任意位置并自动贴合边缘，
重启后回到原位。托盘常驻，余额跌破阈值时用三种方式同时提醒你。

它也会对你做点反应：悬停会害羞、拎起来会乖乖闭眼、没人理就打个瞌睡、
余额跌破阈值会哭一下。全部反应都能在设置里逐项关掉。

WPF / .NET 10，**零第三方 NuGet 依赖**。

---

## 功能

| | |
|---|---|
| **余额显示** | 桌宠脚下一条余额条，绿/橙/红三色状态点；默认 60 秒自动刷新 |
| **拖拽与吸附** | 按住拖动，松手自动贴合最近的屏幕边缘（避让任务栏），位置记忆 |
| **右键菜单** | 在宠物身上直接右键：显示/隐藏、立即刷新、设置、关于、退出（与托盘同一份定义） |
| **托盘** | 显示/隐藏、立即刷新、设置、关于、退出；tooltip 同步余额 |
| **低余额提醒** | 跌破阈值那一刻触发一次（不是每轮都弹）：气泡 + 托盘图标变警示 + 宠物换成疲惫表情 |
| **错误提示** | 密钥失效、限流、服务端故障、网络中断分别给出可读文案，并自动退避重试 |

### 互动

全部动效都可在设置里逐项关掉（见 [配置](#配置)）。

| 交互 | 反应 |
|---|---|
| 鼠标**悬停** | 冒爱心害羞。要停留 0.5 秒，且两次之间至少隔 8 秒 |
| **按住拖拽** | 闭上眼乖乖被拎起来，浮动暂停 |
| **单击** | 刷新余额 + 向上弹跳一下 |
| **长时间没理它**（约 3 分钟） | 打瞌睡：闭眼 + 缓慢深呼吸，鼠标一碰就醒 |
| **余额上涨** | 向上弹跳 |
| **跌破阈值那一刻** | 哭一下（约 2.5 秒）后回到疲惫表情 |
| **回升过阈值** | 轻轻起伏一下归位 |
| **待机眨眼** | 默认**关闭**，原因见下 |

> **眨眼为什么默认关着。** 用脚本实测过 base 与三张 `blink_*` 在两者都不透明区域的
> 逐像素色差：轮廓能对齐（差异 1.1–1.2%），但**平均色差 11.16 / 11.41 / 13.35**，
> 有 20–24% 的像素差值超过 8，`blink_half_open` 与 `blink_half` 更是几乎同一张。
> 它们不是同一批次的动画序列帧，而是不同情绪的立绘，硬当成眨眼会看出明显的跳色。
> 素材留在仓库里、开关也留着，但默认不启用。想要就自己在设置里勾上。

**明确不做**（到 V1.5 为止）：点击穿透、用量统计、天气、对话、开机自启、换皮/多角色。

---

## 运行

### 直接跑（需要 .NET 10 桌面运行时）

```powershell
dotnet run --project src\DeepSeekPet\DeepSeekPet.csproj
```

### 打包成单个 exe（免装运行时）

```powershell
dotnet publish src\DeepSeekPet\DeepSeekPet.csproj -c Release -r win-x64 `
  --self-contained true `
  -p:PublishSingleFile=true `
  -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:PublishTrimmed=false `
  -p:EnableCompressionInSingleFile=true
```

产物在 `src\DeepSeekPet\bin\Release\net10.0-windows\win-x64\publish\`。

> `-p:PublishTrimmed=false` **不能删**。WPF 完全不支持裁剪（`PublishTrimmed`/`PublishAot`），
> 开了会黑屏或直接崩溃。

> **如果程序启动后瞬间消失、且 `%LOCALAPPDATA%\DeepSeekPet\log.txt` 是空的**，
> 那不是代码的问题 —— 很可能是 **Smart App Control** 拦下了这个刚编译出来、没有签名的程序。
> 查 `HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy\VerifiedAndReputablePolicyState`，
> 值为 `1` 即处于强制模式；事件查看器的
> 「应用程序控制策略 / CodeIntegrity」里会有事件 ID 3077（被拒的是 `DeepSeekPet.dll`）。
>
> **但「值为 1」并不等于「一定跑不起来」—— 拦截是间歇性的。** 2026-10-09 在同一台机器上
> 实测：当天 20:58–21:35 连续拦了 16 次，**21:35:31 之后再没有出现过任何一次**；
> 其后重新编译的 DLL（全新哈希）照常加载，程序连续运行 50 分钟以上，
> 同一时段内新编译、从未在本机出现过的未签名控制台程序也能直接运行。
> 而当时策略文件仍留在 `CIPolicies\Active`、注册表仍为 `1`，事件日志里也**没有任何**
> 策略变更记录 —— 这个矛盾没能查清，所以无法保证它会一直放行。
>
> 因此顺序应当是：**先直接运行**。真被拦了再二选一 —— 关掉 Smart App Control，
> 或者给程序做代码签名。前者是**单向操作**（想再打开必须重置或重装 Windows），请自行权衡。

---

## 首次使用

首次启动会自动弹出设置窗口。填入 API Key 即可：

1. 到 <https://platform.deepseek.com/api_keys> 生成一个 `sk-` 开头的密钥
2. 粘贴进设置窗口，保存

没配置时余额条显示「未设置」，不会假装在工作。

## 配置

`%APPDATA%\DeepSeekPet\settings.json`（纯文本，不含密钥）：

```jsonc
{
  "Version": 2,
  "Window":  { "Left": 2520, "Top": 1257, "MonitorDeviceName": "\\\\.\\DISPLAY1" },
  "Balance": { "PreferredCurrency": "CNY", "LowBalanceThreshold": 10.00, "RefreshSeconds": 60 },
  "Tray":    { "ShowBalloonOnLowBalance": true },
  "Animation": {
    "Enabled":     true,   // 总开关；关掉后浮动/反应/眨眼全停，空闲 CPU 回到最低
    "Blink":       false,  // 待机眨眼，默认关（实测色差偏大，见上）
    "Reactions":   true,   // 悬停 / 按住 / 单击
    "BalanceMood": true    // 余额涨跌情绪
  }
}
```

`Left`/`Top` 是**物理像素**（不是 DIP）。刷新间隔有效范围 15–600 秒，界面上会被夹取。

`Animation` 段是 V1.5 新加的。旧的 `settings.json` 里没有这一段时**不需要迁移** ——
`System.Text.Json` 会保留属性初始化值（四个都是 `true`，`Blink` 是 `false`）。
但要注意一个反直觉的规则：**缺键保留默认值，而显式写 `null` 会把值真的置空**，
所以这两种情况在代码里是分开处理的。

设置窗口里改完保存即刻生效，不必重启 —— `Animation.Enabled` 关掉时，
余额状态换图（正常/疲惫/报错）**依然工作**，因为那是功能不是动效。

日志：`%LOCALAPPDATA%\DeepSeekPet\log.txt`（512 KB 滚动）。桌宠没有控制台，出问题先看这个。

---

## 关于 API Key 的安全等级（如实说明）

密钥用 **DPAPI**（`DataProtectionScope.CurrentUser`）加密后存放在
`%LOCALAPPDATA%\DeepSeekPet\apikey.bin`，不上传、不进配置文件与仓库。

**这是混淆级，不是真正的安全。** 以**同一个 Windows 账户**运行的任何程序都能把它解出来。
它能防住的只有这几类：别人直接拷走文件、另一个 Windows 账户、备份/同步泄漏。

客户端持有第三方密钥这件事本身就无法做到真正保密 —— 要做到得走服务端代理。
如果你不能接受这个前提，请不要用本程序，或者用一个额度很小的专用密钥。

另外：密文放在 `LOCALAPPDATA` 而不是 `Roaming` 是刻意的。DPAPI 密文绑定「本机 + 本用户」，
放进会漫游同步的目录，换台机器就解不开了。

---

## 无 Key、无网络也能测（离线验证）

余额客户端有一层接口，`FakeBalanceClient` 由环境变量驱动，可以完整跑通全部功能：

```powershell
$env:DEEPSEEPET_FAKE_BALANCE  = '110.00'          # 假余额
$env:DEEPSEEPET_FAKE_ERROR    = '401'             # 合成失败
$env:DEEPSEEPET_FAKE_DELAY_MS = '800'             # 模拟延迟，用于验证请求不重叠
$env:DEEPSEEPET_FAKE_BALANCE_SEQ = '110,109.5,111.2'   # 按调用次序取值（取完循环）
dotnet run --project src\DeepSeekPet\DeepSeekPet.csproj
```

`DEEPSEEPET_FAKE_ERROR` 取值：`401`（密钥失效）、`402`（余额不足）、`429`（限流）、
`500`/`503`（服务端）、`timeout`、`network`、`decode`、`nokey`。

`DEEPSEEPET_FAKE_BALANCE_SEQ` 优先级高于 `FAKE_BALANCE`，且**每次调用取下一个值、取完循环**，
用于端到端观察「涨 → 跌 → 被节流」：让余额 110 → 109.5 触发一次「跌」，
立刻再点一次宠物（3 秒最小间隔内）能看到手动刷新被合并的日志。
序列如果停在最后一个值不动，就只看得到一轮，所以这里选的是循环而不是钳制。

只要设置了这两个环境变量中的任意一个，就自动切到假客户端，不需要真 Key。
假客户端会**特意走真实的解析路径**，所以 `$env:DEEPSEEPET_FAKE_BALANCE = 'abc'`
能顺带验证十进制解析的护栏（会落到 `DecodeError` 而不是抛异常或算错）。

---

## 项目结构

```
src/DeepSeekPet/
├─ App.xaml.cs              组装根：单实例、生命周期、事件接线
├─ Models/BalanceModels.cs  DTO + 解析（string → decimal，强制 InvariantCulture）
├─ Services/
│  ├─ DeepSeekBalanceClient.cs  真实 HTTP + 状态码 → 错误类型映射
│  ├─ FakeBalanceClient.cs      环境变量驱动的假客户端
│  ├─ BalanceService.cs         轮询、防重叠、退避、低余额跳变检测
│  ├─ BalanceMoodTracker.cs     余额涨跌情绪判定（纯逻辑，时间从外部注入）
│  ├─ PetMenuModel.cs           菜单的唯一定义处，托盘与右键菜单共用
│  ├─ ApiKeyStore.cs            DPAPI 加解密
│  ├─ SettingsStore.cs          settings.json 原子写
│  ├─ TrayIconService.cs        NotifyIcon + 菜单 + 气泡
│  └─ SingleInstance.cs         静态 Mutex（Local\）
├─ Interop/
│  ├─ NativeMethods.cs      Alt+Tab 隐藏（WS_EX_TOOLWINDOW）
│  └─ MonitorHelper.cs      吸附、在屏校验（全程物理像素）
├─ Animation/
│  ├─ PetState.cs           持久基线状态枚举
│  ├─ PetStateMachine.cs    表情决策：分层 + 门控（纯逻辑，零 WPF 引用）
│  ├─ SpriteSet.cs          精灵持有与可选素材降级
│  └─ SpriteAnimator.cs     浮动/弹跳求值、交叉淡入、眨眼调度
├─ ViewModels/PetViewModel.cs
└─ Views/                   桌宠窗口 + 设置窗口
```

---

## 自检（不启动 GUI 也能跑）

```powershell
C:\Users\lenovo\DeepSeekPet-tools\run-selfcheck.ps1
```

59 项断言，覆盖表情门控表、反应到期与作废、余额涨跌节流窗口、解析护栏。

做法是把 `Animation/PetState*.cs`、`Services/BalanceMoodTracker.cs`、
`Models/BalanceModels.cs` 这几个**纯逻辑文件原样链接**进一个 `net48` 类库
（`<Compile Include="...\真实路径.cs" Link="..."/>`，不是复制），编完由 PowerShell 加载执行。
跑的就是发布的那份代码。

之所以绕这么一圈，是因为搭它的时候本机正被拦：2026-10-09 的 20:58–21:35 之间，
`dotnet.exe` 加载 `DeepSeekPet.dll` 被 Smart App Control 拒绝（事件 ID 3077，
表现为秒退、退出码 `0xE0434352`、自己的日志一片空白），而 PowerShell 的 `LoadFrom`
这条路没有被拦 —— 它当时是这台机器上唯一能真正**执行**代码的方式。
（那次拦截在 21:35 之后自行停止了，现在直接跑 GUI 也没问题；这个自检之所以保留，
是因为它不依赖窗口、断言可由机器判定，回归时仍然好用。）

代价是两点妥协，都已处理：`Math.Clamp` / `Random.Shared` 在 .NET Framework 上不存在
（所以状态机里用的是等价的 `Math.Min`/`Math.Max`）；`record` 需要补一个
`IsExternalInit` 垫片，`System.Text.Json` 的标注特性则用一个空实现顶替。

覆盖不到的部分见下节。

---

## 实现中几个值得记下的点

这些是实际踩过或测出来的，不是照搬的通用建议。

**桌面宠物窗口**
- `ShowInTaskbar="False"` **并不能**把窗口从 Alt+Tab 里去掉，必须给 `GWL_EXSTYLE`
  加 `WS_EX_TOOLWINDOW`、清 `WS_EX_APPWINDOW`，再补一次 `SWP_FRAMECHANGED`。
  32 位 user32 **没有** `SetWindowLongPtr` 导出，得按 `IntPtr.Size` 分派。
- `AllowsTransparency="True"` 走的是软件合成的分层窗口路径，每帧都有一次
  GPU→系统内存往返，开销正比于「重绘面积 × 频率」。所以窗口压到 180 DIP、
  只动 `RenderTransform`、动效降到 ~15fps 且**位置没实质变化就不重绘**。
- WPF 的 `Image` **不播放 GIF**（只渲染第一帧），也没有颜色键透明（`LWA_COLORKEY`）。

**几何**
- `Window.Left/Top` 是 DIP，`Screen.WorkingArea` 是物理像素，混用必错。
  本项目的做法是**全程只用物理像素**（`GetWindowRect`/`SetWindowPos`），
  从根上回避换算。本机实测为 200% 缩放（192 DPI），正是最容易出错的场景。
- 还原位置后必须校验矩形是否与当前已连接的显示器相交，否则拔掉显示器后
  桌宠会落在屏幕外，表现为「宠物凭空消失」。

**素材分辨率**
- 桌宠框是 180 DIP。本机 200% 缩放下，180 DIP = 360 物理像素，所以素材取
  **360×360** 并在 `Image` 上用 `Stretch="Uniform"`，屏上恰好 1:1 —— 既最清晰，
  又免掉每帧缩放。实测这一项把空闲 CPU 从单核 2.26% 降到 1.25%。
- `Stretch` 不能是 `None`：`None` 按「1 位图像素 = 1 DIP」绘制，360px 会变成
  360 DIP（200% 下 720 物理像素），直接撑爆裁掉。

**余额接口**
- 金额字段是 **JSON 字符串**（`"110.00"`）而不是数字，必须
  `decimal.TryParse(..., NumberStyles.Number, CultureInfo.InvariantCulture, ...)`。
  不用 `float`/`double`，也绝不用当前区域文化（本机可能就是 zh-CN）。
- `balance_infos` 是**数组**（每个币种一项），需要按偏好币种挑，兜底取第一个。
- 官方没公布限流值（社区共识 30–60 秒），所以：60 秒轮询 + 信号量防重叠 +
  429 退避到 3 倍间隔 + 5xx/网络错误指数退避（上限 5 分钟）。
- **手动刷新是「合并」而不是「排队」**：最初只把它交给信号量，结果连点宠物
  会排出一串真实请求（实测 17 秒内 26 次点击产生 26 次调用）。现在有请求在飞
  就直接丢弃，并且两次手动之间有 3 秒最小间隔。

**互动动效**
- **表情优先级是「分层 + 门控」，不是单一优先级链。** 基线（正常/疲惫/报错）不抢占
  短时反应，而是**决定哪些反应被允许**：低余额时允许害羞、允许哭，但**不允许高兴地弹跳**
  —— 余额并没有涨。这个方向搞反了，宠物就会说谎。
- **眨眼只在解析结果恰好是 `base` 时才允许。** 眨眼帧是 base 姿势的变体，在疲惫/生气/
  按住/睡着时切进去会突然跳回正常眼睛，直接穿帮。
- **点击与拖拽必须消歧，且必须比较绝对屏幕坐标。** 原先在 `DragMove()` **之前**无条件
  触发点击，等于每次拖完都顺带刷一次余额。更坑的是：`DragMove()` 的语义是保持
  「光标在窗口内的相对位置不变」，所以**相对坐标拖完几乎不变** —— 拿它当判据的话，
  每一次拖拽都会被误判成点击。改用 `Visual.PointToScreen` 拿到光标的绝对屏幕位置，
  位移 < 4 且 < 400ms 才算点击。
- **右键菜单用原生 WPF `ContextMenu`，不复用托盘的 WinForms `ContextMenuStrip`。**
  本程序从不调用 WinForms 的 `Application.Run`，没有 WinForms 消息循环，
  而 `ContextMenuStrip.Show()` 会另起一个消息泵 —— 在 `DragMove()` 刚返回、
  或设置窗 `ShowDialog()` 的模态循环之上再叠一个，是焦点丢失和「点外面不关」的经典来源。
- **半像素量化的守卫只能写成「小于阈值就提前返回」。** `_lastAppliedY` 的哨兵值是 `NaN`，
  而 NaN 的任何比较都是 false —— 写成「大于等于才提交」会让守卫永远不通过，宠物直接不动。
- **反应位移与浮动做加权混合，不是相加。** 向上余量是「窗口留的 6 DIP + 素材自身顶部留白」，
  实测最紧的是 `disappointed.png`（顶部留白仅 3px = 1.5 DIP），合计只有 **7.5 DIP**。
  相加会让上限变成 3 + 4.5 = 7.5 DIP，恰好把余量吃光；混合则严格封顶 4.5 DIP，
  两端各带 15% 斜坡，交接处不跳变。
- **不能向右、向下平移，也不能旋转或缩放。** 实测九张素材的不透明内容**齐着画布右边缘和
  下边缘**（bbox 的 R=0、B=0，最后一行列是实心像素）—— 角色是胸像，头发和身体本来就被
  画布裁断了。任何向右/向下的位移、顺时针旋转、整体拉伸都会切掉角色。
  「垂头」这种向下的姿态只能靠 `disappointed.png` 这种**素材本身**表达，而不是靠 Transform。
- **浮动用累积角相位推进，而不是「当前时间 ÷ 周期」。** 睡着时周期从 3.2 秒变 6.4 秒，
  直接除会让 `cos` 的自变量跳变，看起来像瞬间弹了一下。
- **眨眼是硬切，不是交叉淡入。** 它本来就只有约 175ms，每帧再套 250ms 淡入只会糊成一团灰。

**Windows 11 的现实**
- `ShowBalloonTip` 已降级：瞬态、不进操作中心、忽略 timeout 参数、可能被
  专注助手/勿扰静默吞掉，甚至调用成功但什么都不显示。所以气泡只当**尽力而为**，
  真正保证能传达信息的是另外三条：托盘 tooltip 文本、低余额时换警示图标、
  宠物本身换疲惫表情。
- 退出时必须**先 `Visible=false` 再 `Dispose()`**，否则托盘区会残留一个
  悬停才消失的幽灵图标。
- `NotifyIcon.Text` 上限约 127 字符，超长会抛异常，写入前必须截断。

**生命周期**
- 单实例的 `Mutex` **必须挂在静态字段上**。若是局部变量，被 GC 回收时终结器
  会释放锁，第二个实例就能起来。用 `Local\` 前缀只约束当前登录会话。
- `ShutdownMode=OnExplicitShutdown` 下，任务管理器的「结束任务」和 `taskkill`
  （不带 `/f`）都会发 `WM_CLOSE`。若不拦，窗口被关掉而进程不退出 —— 结果是
  托盘还在，宠物却再也显示不出来（已关闭的 `Window` 不能再 `Show`）。
  所以主窗口默认把关闭请求转成「隐藏」。
- 启动时曾有竞态：第一次余额请求（本地/快速响应时约 40ms 就返回）可能早于
  `OnContentRendered`，于是真实余额被初始占位符覆盖，表现为「红点 + 空值」。
  已把占位状态移到构造期。

---

## 未经验证的部分（如实标注）

V1.5 的互动动效是在一个 **Smart App Control 间歇拦人的环境**里写的：写到一半本机突然
跑不起来了（20:58–21:35 被连拦 16 次，详见上面的运行说明），所以**动效本身从未被运行验收过**——
下面这些至今没有被人眼或实测确认，只有纯逻辑那一层是真跑过的：

| 未验证项 | 说明 | 怎么关掉 |
|---|---|---|
| 眨眼在真实眼睛下的观感 | 色差数据强烈提示不好看，但没人真的看过 | 设置里不勾「待机眨眼」（默认已关） |
| 右键菜单在分层置顶窗口上的 z-order 与关闭行为 | 声明式 `ContextMenu` 走的是框架标准路径，理论上免费获得正确行为，但没实测 | 用托盘菜单做同一件事 |
| 分层窗口重绘的真实 CPU 增量 | 只能从既有实测外推：全开约 1.25% → 1.4~1.6% | 关掉「启用互动动效」，回到 1.25% |
| 弹跳/呼吸的幅度是否真的好看 | 几何上安全（峰值 4.5 DIP < 最小顶部余量 7.5 DIP），但手感未经人眼确认 | 同上 |

**已经验证的**：编译（含 XAML 的 `x:Name` 与事件绑定，由 XamlCompiler 在编译期校验）、
59 项纯逻辑断言、以及用脚本从素材算出的几何余量与眨眼色差 —— 后者是确定性的数据，
不靠肉眼。

另外，**我本人没有用真实 `sk-` 密钥跑过一次** —— 上面这些验证走的是 `FakeBalanceClient`。
不过这台机器上的日常使用已经覆盖了真实 HTTP 路径：2026-10-09 21:39 起，桌面上的实例用
真实密钥连续轮询了 50 分钟以上（日志里 55 次 `开始刷新`，并有由真实余额变动触发的
`余额下降` 记录 —— 伪客户端只会返回定值，产生不了这个），全程没有退避或错误告警。
也就是说**成功路径**已由实际使用验证；**错误分支**（状态码映射、退避、限流）仍未触发过。

---

## 许可

代码原创。角色素材来自 MIT 许可的开源项目，版权归原作者所有 ——
详见 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)。

与 DeepSeek 官方无任何隶属或背书关系。
